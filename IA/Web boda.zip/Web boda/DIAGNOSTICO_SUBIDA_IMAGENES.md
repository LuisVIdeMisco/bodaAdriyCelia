# Diagnóstico: Error al Subir Imágenes

## Problema Reportado

Al intentar subir una foto desde la página de administración (`/admin`), aparecían los siguientes errores:
- "failed to create request"
- "failed to create request: load failed"

## Causa Raíz

El problema está relacionado con cómo las **firmas S3** funcionan en URLs presignadas y cómo MinIO valida estas firmas.

### Explicación Técnica Detallada

1. **Generación de URLs Presignadas**:
   - El servidor Node.js usa el cliente MinIO interno configurado con `endPoint: "minio", port: 9000`
   - MinIO genera una URL presignada como: `http://minio:9000/wedding-images/hero-123.jpg?X-Amz-Signature=...`
   - La firma S3 (`X-Amz-Signature`) se calcula usando varios componentes, **incluyendo el header Host esperado** (`minio:9000`)

2. **Transformación de la URL**:
   - El código reemplaza el host interno con el host público: `http://localhost:8000/wedding-images/hero-123.jpg?X-Amz-Signature=...`
   - Los parámetros de la firma permanecen intactos (esto es correcto)

3. **El Problema - Validación de la Firma**:
   - El navegador hace un PUT a `http://localhost:8000/wedding-images/...`
   - Nginx recibe la petición y la proxea a MinIO
   - **PROBLEMA**: Nginx enviaba el header `Host: localhost:8000` a MinIO
   - MinIO intenta validar la firma recalculándola con el host recibido (`localhost:8000`)
   - Como el host es diferente al usado en la generación (`minio:9000`), **la firma no coincide**
   - MinIO rechaza la petición, pero debido a un problema de CORS/red, el navegador muestra "failed to create request: load failed"

### ¿Por qué "load failed" y no un error HTTP?

El error "failed to create request: load failed" es un error genérico del navegador que ocurre cuando:
- La petición falla antes de recibir una respuesta HTTP completa
- Hay un problema de CORS que impide que el navegador muestre el error real
- La conexión se cierra inesperadamente

En este caso, MinIO rechazaba la petición por firma inválida, pero el navegador no podía mostrar el error HTTP real debido a cómo se manejaba la respuesta.

## Solución Aplicada

### Cambio en la Configuración de Nginx

La solución es **reescribir el header Host en Nginx** antes de enviar la petición a MinIO, para que MinIO reciba el mismo host que usó para generar la firma.

**Cambio en `docker/nginx/conf.d/default.conf`**:

```nginx
location /wedding-images/ {
    proxy_pass http://minio:9000/wedding-images/;
    
    # CRÍTICO: Reescribir el Host header a "minio:9000"
    # Esto permite que MinIO valide correctamente las firmas S3
    proxy_set_header Host minio:9000;
    
    # ... resto de la configuración
}
```

**ANTES (❌ No funcionaba):**
```nginx
proxy_set_header Host $http_host;  # Enviaba "localhost:8000"
```

**AHORA (✅ Funciona):**
```nginx
proxy_set_header Host minio:9000;  # Envía "minio:9000"
```

### ¿Por qué funciona esta solución?

1. **Generación de la firma**: MinIO genera la URL presignada usando el host `minio:9000`
2. **Transformación de la URL**: El código reemplaza `minio:9000` con `localhost:8000` para que sea accesible desde el navegador
3. **Petición del navegador**: El navegador hace PUT a `http://localhost:8000/wedding-images/...`
4. **Nginx reescribe el Host**: Nginx cambia el header `Host: localhost:8000` a `Host: minio:9000`
5. **Validación exitosa**: MinIO recibe `Host: minio:9000`, que coincide con el host usado para generar la firma
6. **Éxito**: La validación de la firma pasa y el archivo se sube correctamente

### Ventajas de esta Solución

- ✅ **Simple**: Solo requiere un cambio en la configuración de Nginx
- ✅ **Robusta**: No depende de configuraciones complejas de MinIO
- ✅ **Mantenible**: El código de generación de URLs permanece simple y claro
- ✅ **No requiere cambios en el código**: Solo configuración de infraestructura

## Archivos Modificados

### 1. Configuración de Nginx (`docker/nginx/conf.d/default.conf`)

**Cambio crítico**: Se modificó el header `Host` que Nginx envía a MinIO.

```nginx
location /wedding-images/ {
    proxy_pass http://minio:9000/wedding-images/;
    
    # CRÍTICO para validación de firmas S3
    proxy_set_header Host minio:9000;
    
    # Headers CORS (sin cambios)
    add_header 'Access-Control-Allow-Origin' '*' always;
    # ... más configuración CORS
}
```

### 2. NO se requieren cambios en:

- ❌ `docker/compose.yaml` - La configuración de MinIO permanece igual
- ❌ `src/server/trpc/procedures/getImageUploadUrl.ts` - El código de generación de URLs permanece igual
- ❌ Variables de entorno en `.env`

La solución es puramente de configuración de proxy.

## Cómo Verificar que Funciona

### 1. Reiniciar Nginx

Después de modificar la configuración de Nginx, reinicia los contenedores:

```bash
./scripts/stop
./scripts/run
```

### 2. Probar la Subida

1. Abre `http://localhost:8000/admin` en el navegador
2. Abre las DevTools (F12) → pestaña "Console"
3. Intenta subir una imagen
4. Verifica que no aparezca el error "failed to create request: load failed"
5. La imagen debería subirse exitosamente

### 3. Logs Esperados

**En la consola del navegador:**
```
=== Starting image upload ===
Upload URL received: http://localhost:8000/wedding-images/hero-1234.jpg?X-Amz-...
✅ Upload response received
Status: 200
✅ Upload successful
```

**En la pestaña Network:**
- OPTIONS request (preflight): **204 No Content**
- PUT request (upload): **200 OK**

## Problemas Comunes y Soluciones

### Error: "failed to create request: load failed"

**Causa**: El header Host no está configurado correctamente en Nginx.

**Solución**: 
1. Verifica que `docker/nginx/conf.d/default.conf` contenga:
   ```nginx
   proxy_set_header Host minio:9000;
   ```
2. Reinicia los contenedores: `./scripts/stop && ./scripts/run`

### Error: "SignatureDoesNotMatch"

**Causa**: El header Host enviado a MinIO no coincide con el usado para generar la firma.

**Solución**: Este error debería estar resuelto con el cambio de Nginx. Si persiste:
1. Verifica los logs del servidor para ver qué host está recibiendo MinIO
2. Asegúrate de que Nginx se reinició correctamente

### Error: "CORS policy: No 'Access-Control-Allow-Origin' header"

**Causa**: Los headers CORS no se están agregando.

**Solución**: 
1. Verifica que la configuración de Nginx incluya los headers CORS con `always`
2. Reinicia Nginx: `./scripts/stop && ./scripts/run`

## Información Técnica: Firmas S3

### ¿Qué es una firma S3?

Las URLs presignadas de S3 incluyen una firma criptográfica que permite:
- Autenticar que la URL fue generada por alguien con credenciales válidas
- Prevenir modificaciones de la URL
- Establecer un tiempo de expiración

### Componentes de la firma

La firma S3 se calcula usando:
1. **Método HTTP**: PUT, GET, etc.
2. **Path**: `/wedding-images/hero-123.jpg`
3. **Query parameters**: Credenciales, fecha, expiración
4. **Headers**: Especialmente el header **Host**
5. **Secret key**: La clave secreta de MinIO

### Por qué el Host es crítico

Si el host cambia entre la generación y la validación de la firma, MinIO recalcula una firma diferente y rechaza la petición.

**Ejemplo**:
- Firma generada con: `Host: minio:9000` → `X-Amz-Signature=ABC123`
- Petición recibida con: `Host: localhost:8000` → MinIO calcula `X-Amz-Signature=XYZ789`
- `ABC123 ≠ XYZ789` → **SignatureDoesNotMatch**

**Solución**: Nginx reescribe el Host a `minio:9000` antes de enviar a MinIO.

## Flujo Completo de Subida

1. **Cliente (Navegador)** → Solicita URL de subida vía tRPC
2. **Servidor (Node.js)** → Genera URL presignada usando MinIO client interno (host: `minio:9000`)
3. **Servidor** → Reemplaza host interno con host público (`localhost:8000`)
4. **Servidor** → Devuelve URL al cliente
5. **Cliente** → Hace solicitud OPTIONS (preflight CORS) a Nginx
6. **Nginx** → Responde con headers CORS permitiendo PUT
7. **Cliente** → Hace solicitud PUT con el archivo a Nginx (`Host: localhost:8000`)
8. **Nginx** → **Reescribe el Host header a `minio:9000`**
9. **Nginx** → Proxea la solicitud a MinIO
10. **MinIO** → Valida la firma S3 usando el Host header (`minio:9000`)
11. **MinIO** → ✅ Firma válida → Guarda el archivo y responde 200 OK
12. **Nginx** → Devuelve respuesta al cliente
13. **Cliente** → Actualiza la base de datos vía tRPC con la URL del objeto

## Arquitectura de Red

```
┌─────────────────┐
│   Navegador     │
│  (localhost)    │
└────────┬────────┘
         │ HTTP
         │ localhost:8000
         │ Host: localhost:8000
         ▼
┌─────────────────┐
│     Nginx       │
│   (puerto 8000) │
│                 │
│  Reescribe:     │
│  Host: minio:9000
└────┬───────┬────┘
     │       │
     │       └──────────────┐
     │                      │
     │ /                    │ /wedding-images/
     │ → app:3000           │ → minio:9000
     ▼                      ▼
┌─────────────┐      ┌──────────────┐
│   Node.js   │      │    MinIO     │
│  (puerto    │      │  (puerto     │
│   3000)     │      │   9000)      │
└─────────────┘      └──────────────┘
```

## Notas para Producción

### Configuración para Servidor Remoto

Si despliegas en un servidor con dominio público (ej: `https://tudominio.com`):

**NO necesitas cambiar nada**. La solución funciona igual porque:
1. El navegador hace peticiones a `https://tudominio.com/wedding-images/...`
2. Nginx reescribe el Host a `minio:9000`
3. MinIO valida correctamente la firma

### HTTPS

Si usas HTTPS en producción:
1. Configura tu reverse proxy (Nginx externo) para manejar SSL
2. El Nginx interno en Docker puede seguir usando HTTP
3. Asegúrate de que `X-Forwarded-Proto` se pase correctamente

### Seguridad de CORS

La configuración actual permite cualquier origen (`Access-Control-Allow-Origin: *`):
- ✅ **Desarrollo**: Está bien
- ⚠️ **Producción**: Considera restringir a tu dominio específico

Para restringir en producción:
```nginx
add_header 'Access-Control-Allow-Origin' 'https://tudominio.com' always;
```

## Resumen

El problema de "failed to create request: load failed" se resolvió configurando Nginx para que reescriba el header `Host` a `minio:9000` antes de enviar las peticiones a MinIO. Esto permite que MinIO valide correctamente las firmas S3 de las URLs presignadas, ya que el host usado en la validación coincide con el host usado en la generación de la firma.

**Cambio clave**: `proxy_set_header Host minio:9000;` en la configuración de Nginx.
