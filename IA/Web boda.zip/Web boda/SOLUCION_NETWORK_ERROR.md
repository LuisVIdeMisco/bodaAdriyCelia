# Solución: Error "failed to create request: network error"

## Problema Reportado

Al intentar subir fotos desde la página de administración (`/admin`), aparece el error:
```
failed to create request: network error
```

Este es un error **diferente** al error anterior "failed to create request: load failed" que ya fue resuelto.

## Diferencia con el Error Anterior

| Error Anterior | Error Actual |
|----------------|--------------|
| `failed to create request: load failed` | `failed to create request: network error` |
| Causado por firma S3 inválida (403) | Causado por fallo de conexión de red |
| La petición HTTP llega a MinIO pero es rechazada | La petición HTTP ni siquiera se puede iniciar |
| Solución: Reescribir Host header en Nginx | Solución: Verificar conectividad y configuración |

## ¿Qué Significa "network error"?

El error "network error" es un error genérico del navegador que ocurre cuando:

1. **El navegador no puede conectarse al servidor**
   - El puerto no está accesible
   - El host no se puede resolver
   - Hay un firewall bloqueando la conexión

2. **La URL es inválida o malformada**
   - Protocolo incorrecto (ej: `minio://` en lugar de `http://`)
   - Host vacío o con caracteres inválidos
   - Puerto fuera de rango

3. **Problema de protocolo mixto (Mixed Content)**
   - La página se carga con HTTPS pero intenta hacer una petición HTTP
   - El navegador bloquea la petición por seguridad

4. **Extensión del navegador bloqueando la petición**
   - Bloqueador de anuncios
   - Extensión de privacidad
   - Antivirus con protección web

5. **Docker/Nginx no está funcionando correctamente**
   - Los contenedores no están corriendo
   - Nginx no está escuchando en el puerto 8000
   - Hay un problema de red entre contenedores

## Diagnóstico Paso a Paso

### Paso 1: Verificar que Docker está Corriendo

Primero, asegúrate de que todos los contenedores están corriendo:

```bash
docker ps
```

**Debes ver estos contenedores:**
- `nginx` (puerto 8000)
- `minio` (puertos 9000 y 9001)
- `app` (puerto 3000)
- `postgres`
- `redis`
- `adminer`

**Si falta alguno:**
```bash
# Ver logs de todos los contenedores
docker ps -a

# Ver logs de un contenedor específico
docker logs <nombre-contenedor>

# Si hay contenedores detenidos, reinicia todo
./scripts/stop
./scripts/run
```

### Paso 2: Verificar que Nginx está Escuchando

Verifica que Nginx está escuchando en el puerto 8000:

```bash
# En Linux/Mac
curl -I http://localhost:8000

# Deberías ver algo como:
# HTTP/1.1 200 OK
# ...
```

**Si obtienes "Connection refused":**
- Nginx no está corriendo o no está escuchando en el puerto 8000
- Verifica los logs: `docker logs <nombre-contenedor-nginx>`
- Reinicia: `./scripts/stop && ./scripts/run`

**Si obtienes "Could not resolve host":**
- Hay un problema con tu configuración de DNS local
- Prueba con `127.0.0.1` en lugar de `localhost`

### Paso 3: Verificar que MinIO es Accesible a través de Nginx

Verifica que puedes acceder a MinIO a través del proxy de Nginx:

```bash
# Intenta acceder a un archivo de prueba (esto dará 404 pero es OK)
curl -I http://localhost:8000/wedding-images/test.jpg

# Deberías ver algo como:
# HTTP/1.1 404 Not Found
# o
# HTTP/1.1 403 Forbidden
# (ambos son OK - significa que Nginx está proxeando a MinIO)
```

**Si obtienes "Connection refused":**
- El proxy de Nginx no está configurado correctamente
- Verifica la configuración: `docker exec <nombre-nginx> cat /etc/nginx/conf.d/default.conf`

**Si obtienes "502 Bad Gateway":**
- Nginx no puede conectarse a MinIO
- Verifica que MinIO está corriendo: `docker ps | grep minio`
- Verifica los logs de MinIO: `docker logs <nombre-minio>`

### Paso 4: Verificar la Configuración de Nginx

Esta es la configuración **crítica** que debe estar correcta:

```bash
# Ver la configuración de Nginx
docker exec $(docker ps --filter "ancestor=nginx:latest" --format "{{.Names}}" | head -1) cat /etc/nginx/conf.d/default.conf | grep -A 30 "location /wedding-images/"
```

**Debes ver:**
```nginx
location /wedding-images/ {
    proxy_pass http://minio:9000/wedding-images/;
    
    # CRÍTICO: Debe ser "minio:9000"
    proxy_set_header Host minio:9000;
    
    # Headers CORS con 'always'
    add_header 'Access-Control-Allow-Origin' '*' always;
    add_header 'Access-Control-Allow-Methods' 'GET, PUT, POST, DELETE, OPTIONS, HEAD' always;
    # ...
}
```

**Si la configuración está incorrecta:**
1. Edita `docker/nginx/conf.d/default.conf`
2. Asegúrate de que tenga `proxy_set_header Host minio:9000;`
3. Reinicia: `./scripts/stop && ./scripts/run`
4. Vuelve a verificar

### Paso 5: Verificar los Logs del Navegador

Abre la página de administración y abre las DevTools (F12):

1. Ve a la pestaña **Console**
2. Limpia la consola (icono de 🚫 o Ctrl+L)
3. Intenta subir una imagen
4. Busca estos logs:

**Logs esperados (inicio del proceso):**
```
=== Starting image upload ===
File name: mi-foto.jpg
File size: 123456 bytes
Requesting upload URL...
Upload URL received: http://localhost:8000/wedding-images/...
```

**Si NO ves "Upload URL received":**
- El problema está en la llamada tRPC a `getImageUploadUrl`
- Busca errores de tRPC en la consola
- Ve al Paso 6 para verificar el backend

**Si ves "Upload URL received" pero luego falla:**
- El problema está en la petición PUT al upload URL
- Busca el error específico en la consola
- Ve al Paso 7 para diagnóstico específico

### Paso 6: Verificar el Backend (tRPC)

Si la llamada a `getImageUploadUrl` falla, verifica el backend:

```bash
# Ver logs del contenedor de la app
docker logs $(docker ps --filter "name=app" --format "{{.Names}}" | head -1) --tail 100 --follow
```

Intenta subir una imagen y busca:

**Logs esperados:**
```
=== Generating presigned URL ===
Bucket: wedding-images
Object: hero-1234567890.jpg
Request host: localhost:8000
Internal URL generated: http://minio:9000/wedding-images/...
Public upload URL: http://localhost:8000/wedding-images/...
✅ URL validation passed
```

**Si ves errores:**
- `Bucket does not exist`: Ejecuta el setup: `docker exec <nombre-app> pnpm prisma db push`
- `Connection refused`: MinIO no está accesible desde el contenedor de app
- `Invalid credentials`: La contraseña de MinIO es incorrecta

### Paso 7: Diagnóstico Específico del Error "network error"

Si llegaste aquí, el error está en el fetch del navegador. Analiza el error en la consola:

**Error A: "TypeError: Failed to fetch"**
```
❌ Fetch error: TypeError: Failed to fetch
Error name: TypeError
Error message: Failed to fetch
```

**Causas posibles:**
1. **Extensión del navegador bloqueando la petición**
   - Solución: Desactiva todas las extensiones o prueba en modo incógnito
   - Chrome: Ctrl+Shift+N, Firefox: Ctrl+Shift+P

2. **Antivirus o firewall bloqueando la conexión**
   - Solución: Desactiva temporalmente el antivirus
   - O añade `localhost:8000` a la lista blanca

3. **URL malformada**
   - Busca en los logs: `Upload URL received: ...`
   - Copia la URL y pégala en una nueva pestaña
   - Si la URL no carga, hay un problema con cómo se genera

**Error B: "NetworkError when attempting to fetch resource"**

Este error específico de Firefox indica:
1. **CORS bloqueando la petición**
   - Verifica que Nginx tenga los headers CORS con `always`
   - Ve al Paso 4 para verificar la configuración

2. **Protocolo mixto**
   - Verifica que accedes a `http://localhost:8000` (sin 's')
   - Si accedes con HTTPS, el navegador bloquea peticiones HTTP

**Error C: "net::ERR_CONNECTION_REFUSED"**

Este error específico de Chrome indica:
1. **El puerto no está accesible**
   - Verifica que Nginx está corriendo: `docker ps`
   - Verifica que escucha en 8000: `curl -I http://localhost:8000`

2. **Firewall bloqueando el puerto**
   - Desactiva el firewall temporalmente
   - O añade una regla para el puerto 8000

## Soluciones Específicas

### Solución 1: Reiniciar Docker Completamente

Esta es la solución más común y debería ser lo primero que intentes:

```bash
# 1. Detener todos los servicios
./scripts/stop

# 2. Esperar a que todo se detenga
sleep 5

# 3. Verificar que no hay contenedores corriendo
docker ps

# 4. Iniciar de nuevo
./scripts/run

# 5. Esperar a que todo esté listo (30-60 segundos)
sleep 30

# 6. Verificar que todo está corriendo
docker ps
```

**¿Por qué funciona esto?**
- Los cambios en la configuración de Nginx NO se aplican hasta reiniciar
- Docker puede tener cache de configuraciones antiguas
- Los contenedores pueden estar en un estado inconsistente

### Solución 2: Verificar y Corregir la Configuración de Nginx

Si el reinicio no funciona, verifica la configuración:

```bash
# 1. Ver la configuración actual
docker exec $(docker ps --filter "ancestor=nginx:latest" --format "{{.Names}}" | head -1) cat /etc/nginx/conf.d/default.conf | grep -A 10 "proxy_set_header Host"

# Debes ver:
# proxy_set_header Host minio:9000;

# Si ves algo diferente (ej: $http_host), la configuración está MAL
```

**Si la configuración está incorrecta:**

1. Abre `docker/nginx/conf.d/default.conf` en tu editor
2. Busca la sección `location /wedding-images/`
3. Verifica que tenga:
   ```nginx
   proxy_set_header Host minio:9000;
   ```
4. Si no lo tiene, cámbialo
5. Guarda el archivo
6. Reinicia: `./scripts/stop && ./scripts/run`

### Solución 3: Probar en Modo Incógnito

Las extensiones del navegador pueden bloquear peticiones:

**Chrome:**
```
1. Ctrl+Shift+N (Windows/Linux) o Cmd+Shift+N (Mac)
2. Ve a http://localhost:8000/admin
3. Intenta subir una imagen
```

**Firefox:**
```
1. Ctrl+Shift+P (Windows/Linux) o Cmd+Shift+P (Mac)
2. Ve a http://localhost:8000/admin
3. Intenta subir una imagen
```

**Si funciona en modo incógnito:**
- El problema es una extensión del navegador
- Desactiva las extensiones una por una para encontrar la culpable
- Extensiones comunes que causan problemas:
  - Bloqueadores de anuncios (uBlock Origin, AdBlock)
  - Extensiones de privacidad (Privacy Badger, Ghostery)
  - Extensiones de seguridad (HTTPS Everywhere)

### Solución 4: Probar con 127.0.0.1 en lugar de localhost

Algunos sistemas tienen problemas con la resolución de `localhost`:

```bash
# En lugar de:
http://localhost:8000/admin

# Prueba con:
http://127.0.0.1:8000/admin
```

**Si esto funciona:**
- Hay un problema con la resolución DNS de `localhost`
- Puedes seguir usando `127.0.0.1`
- O arreglar tu archivo `/etc/hosts` (Linux/Mac) o `C:\Windows\System32\drivers\etc\hosts` (Windows)

### Solución 5: Verificar el Archivo .env

Verifica que tu archivo `.env` tenga las variables correctas:

```bash
cat .env | grep ADMIN_PASSWORD
```

**Debe mostrar:**
```
ADMIN_PASSWORD=<algún-valor-largo>
```

**Si está vacío o falta:**
1. Abre `.env` en tu editor
2. Verifica que tenga `ADMIN_PASSWORD=...`
3. Reinicia: `./scripts/stop && ./scripts/run`

### Solución 6: Limpiar y Reconstruir (Solución Nuclear)

Si nada funciona, prueba esto:

```bash
# ⚠️ ADVERTENCIA: Esto eliminará TODOS los datos
# Solo usa esto en desarrollo

# 1. Detener todo
./scripts/stop

# 2. Eliminar todos los contenedores y volúmenes
docker compose -f docker/compose.yaml down -v

# 3. Eliminar imágenes de Docker (opcional)
docker system prune -a

# 4. Esperar
sleep 5

# 5. Iniciar de nuevo
./scripts/run

# 6. Esperar a que todo se construya (puede tardar varios minutos)
# Verás logs de construcción y setup
```

### Solución 7: Verificar Firewall y Antivirus

**Windows:**
```
1. Abre "Windows Defender Firewall"
2. Clic en "Permitir una aplicación a través del firewall"
3. Busca "Docker" y asegúrate de que está permitido
4. O desactiva el firewall temporalmente para probar
```

**Mac:**
```
1. System Preferences → Security & Privacy → Firewall
2. Click "Firewall Options"
3. Asegúrate de que Docker está permitido
4. O desactiva el firewall temporalmente para probar
```

**Linux:**
```bash
# Verificar si el firewall está bloqueando
sudo iptables -L -n | grep 8000

# Desactivar temporalmente (para probar)
sudo ufw disable

# Reactivar después de probar
sudo ufw enable
```

## Checklist de Verificación

Usa este checklist para asegurarte de que todo está configurado correctamente:

- [ ] Todos los contenedores Docker están corriendo (`docker ps`)
- [ ] Nginx está escuchando en el puerto 8000 (`curl -I http://localhost:8000`)
- [ ] MinIO es accesible a través de Nginx (`curl -I http://localhost:8000/wedding-images/test.jpg`)
- [ ] La configuración de Nginx tiene `proxy_set_header Host minio:9000;`
- [ ] El archivo `.env` tiene `ADMIN_PASSWORD` configurado
- [ ] Los logs del navegador muestran "Upload URL received: http://localhost:8000/wedding-images/..."
- [ ] No hay extensiones del navegador bloqueando peticiones (prueba en modo incógnito)
- [ ] No hay firewall o antivirus bloqueando el puerto 8000
- [ ] Accedes a la página con `http://` (no `https://`)
- [ ] Has reiniciado Docker después de cualquier cambio de configuración

Si todos los items están marcados y el problema persiste, continúa al siguiente paso.

## Recopilación de Información para Soporte

Si después de seguir todos los pasos el problema persiste, recopila esta información:

### 1. Logs del Navegador

Abre DevTools (F12) → Console → Intenta subir una imagen → Copia todos los logs:

```
=== Starting image upload ===
...
(copia todo)
```

### 2. Logs del Servidor

```bash
docker logs $(docker ps --filter "name=app" --format "{{.Names}}" | head -1) --tail 200
```

### 3. Logs de Nginx

```bash
docker logs $(docker ps --filter "ancestor=nginx:latest" --format "{{.Names}}" | head -1) --tail 100
```

### 4. Logs de MinIO

```bash
docker logs $(docker ps --filter "name=minio" --format "{{.Names}}" | head -1) --tail 100
```

### 5. Configuración de Nginx

```bash
docker exec $(docker ps --filter "ancestor=nginx:latest" --format "{{.Names}}" | head -1) cat /etc/nginx/conf.d/default.conf
```

### 6. Estado de Docker

```bash
docker ps -a
docker network ls
```

### 7. Variables de Entorno

```bash
cat .env | grep -v "PASSWORD\|SECRET\|KEY"
```

### 8. Información del Sistema

```bash
# Linux/Mac
uname -a
docker --version
docker compose version

# Windows (PowerShell)
Get-ComputerInfo | Select-Object WindowsVersion, OsHardwareAbstractionLayer
docker --version
docker compose version
```

Con toda esta información, será mucho más fácil identificar el problema específico.

## Resumen

El error "failed to create request: network error" indica que el navegador no puede conectarse al servidor para subir la imagen. Las causas más comunes son:

1. **Docker no está corriendo o Nginx no está funcionando** → Reinicia Docker
2. **Configuración de Nginx incorrecta** → Verifica `proxy_set_header Host minio:9000;`
3. **Extensión del navegador bloqueando la petición** → Prueba en modo incógnito
4. **Firewall o antivirus bloqueando la conexión** → Desactiva temporalmente

## Próximos Pasos

1. **Primero:** Reinicia Docker completamente (`./scripts/stop && ./scripts/run`)
2. **Segundo:** Verifica la configuración de Nginx (Paso 4)
3. **Tercero:** Prueba en modo incógnito
4. **Si nada funciona:** Recopila los logs y busca ayuda

## Diferencia con Otros Errores

| Error | Causa | Solución |
|-------|-------|----------|
| `network error` | No se puede conectar al servidor | Verificar Docker/Nginx está corriendo |
| `load failed` | Firma S3 inválida (403) | Configurar `proxy_set_header Host minio:9000;` |
| `SignatureDoesNotMatch` | Host header incorrecto | Configurar `proxy_set_header Host minio:9000;` |
| `CORS policy` | Headers CORS faltantes | Añadir headers CORS con `always` |
| `timeout` | Subida tarda demasiado | Usar imagen más pequeña |

Cada error tiene una causa y solución diferente. Asegúrate de identificar correctamente el error que estás viendo.
