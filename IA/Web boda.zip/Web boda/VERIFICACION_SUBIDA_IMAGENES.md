# Verificación y Solución: Error al Subir Imágenes

## Problema Resuelto

El error "failed to create request: load failed" al subir imágenes ha sido resuelto mediante un cambio en la configuración de Nginx.

### Causa del Problema

El problema estaba en cómo Nginx enviaba el header `Host` a MinIO:
- MinIO genera URLs presignadas con firmas S3 basadas en el host `minio:9000`
- Nginx enviaba el header `Host: localhost:8000` a MinIO
- MinIO intentaba validar la firma usando `localhost:8000` pero la firma fue calculada con `minio:9000`
- La validación fallaba, causando el error

### Solución Aplicada

Cambiar la configuración de Nginx para que reescriba el header Host:

```nginx
# ANTES (❌ causaba errores)
proxy_set_header Host $http_host;

# AHORA (✅ funciona)
proxy_set_header Host minio:9000;
```

Para más detalles técnicos, consulta `DIAGNOSTICO_SUBIDA_IMAGENES.md`.

## Estado Actual

La configuración ha sido corregida y la subida de imágenes debería funcionar correctamente después de reiniciar los servicios.

## Pasos de Verificación y Solución

### 1. ⚠️ IMPORTANTE: Reiniciar los Servicios

Después de cualquier cambio en la configuración, **DEBES reiniciar los servicios Docker**:

```bash
# Detener todos los servicios
./scripts/stop

# Esperar unos segundos para asegurar que todo se detuvo
sleep 5

# Iniciar todos los servicios de nuevo
./scripts/run
```

**¿Por qué es necesario?**
- Los cambios en `docker/nginx/conf.d/default.conf` NO se aplican hasta que reinicies el contenedor de Nginx
- Los cambios en `docker/compose.yaml` NO se aplican hasta que recrees los contenedores
- El cache de Docker puede causar que se usen configuraciones antiguas

### 2. Verificar que los Servicios Están Corriendo

```bash
docker ps
```

Deberías ver estos contenedores corriendo:
- `nginx` (puerto 8000)
- `minio` (puertos 9000 y 9001)
- `app` (puerto 3000)
- `postgres`
- `redis`
- `adminer`

Si alguno falta, revisa los logs:
```bash
docker logs <nombre-del-contenedor>
```

### 3. Verificar la Configuración de Nginx (CRÍTICO)

Este es el paso más importante. Verifica que Nginx esté configurado correctamente:

```bash
docker exec <nombre-contenedor-nginx> cat /etc/nginx/conf.d/default.conf | grep -A 10 "location /wedding-images/"
```

**Debes ver:**
```nginx
location /wedding-images/ {
    proxy_pass http://minio:9000/wedding-images/;
    ...
    proxy_set_header Host minio:9000;  # ← DEBE ser "minio:9000"
    ...
}
```

**❌ Si ves esto, está MAL:**
```nginx
proxy_set_header Host $http_host;  # ← Esto causa el error
```

**✅ Debe ser esto:**
```nginx
proxy_set_header Host minio:9000;  # ← Esto es correcto
```

Si la configuración está incorrecta:
1. Edita `docker/nginx/conf.d/default.conf`
2. Cambia la línea a `proxy_set_header Host minio:9000;`
3. Reinicia: `./scripts/stop && ./scripts/run`

### 4. Probar la Subida de Imágenes

1. Abre el navegador en `http://localhost:8000/admin`
2. **Abre las DevTools** (F12 o Ctrl+Shift+I)
3. Ve a la pestaña **Console**
4. Ve a la pestaña **Network**
5. Intenta subir una imagen

### 5. Analizar los Logs de la Consola

#### ✅ Logs Exitosos

Si todo funciona correctamente, deberías ver:

```
=== Starting image upload ===
File name: mi-foto.jpg
File size: 123456 bytes
File type: image/jpeg
Image type: hero
Current page URL: http://localhost:8000/admin
Requesting upload URL...
Upload URL received: http://localhost:8000/wedding-images/hero-1234567890.jpg?X-Amz-Algorithm=...
Object name: hero-1234567890.jpg
URL validation passed
URL protocol: http:
URL host: localhost:8000
Starting PUT request...
Attempting fetch to: http://localhost:8000/wedding-images/...
✅ Upload response received
Status: 200
✅ Upload successful, updating database...
✅ Database updated successfully
=== Upload complete ===
```

#### ❌ Logs con Errores

Si ves errores, presta atención a estos mensajes específicos:

**Error 1: "failed to create request: network error"**
```
❌ Fetch error: TypeError: Failed to fetch
Error name: TypeError
```

**Posibles causas:**
- El navegador no puede conectarse a `localhost:8000`
- Firewall o software antivirus bloqueando la conexión
- Extensión del navegador bloqueando la solicitud (ej: bloqueador de anuncios)

**Soluciones:**
- Verifica que estás accediendo a `http://localhost:8000` (no `127.0.0.1`)
- Desactiva temporalmente extensiones del navegador
- Prueba en modo incógnito
- Prueba en otro navegador

**Error 2: "SignatureDoesNotMatch" o "The request signature we calculated does not match"**
```
❌ Upload failed with status: 403
Error response: SignatureDoesNotMatch
```

**Causa:** La firma S3 no coincide. Esto significa que el header `Host` que MinIO recibe no coincide con el host usado para generar la firma.

**Diagnóstico:**
1. Verifica los logs del servidor Node.js para ver qué URL se generó
2. Verifica los logs de MinIO: `docker logs <nombre-contenedor-minio>`
3. El problema es que Nginx NO está reescribiendo el Host header correctamente

**Soluciones:**
1. **Verifica la configuración de Nginx** - Este es el problema más común:
   ```bash
   cat docker/nginx/conf.d/default.conf | grep -A 5 "location /wedding-images/"
   ```
   
   Debes ver:
   ```nginx
   proxy_set_header Host minio:9000;
   ```
   
   Si ves `proxy_set_header Host $http_host;`, ese es el problema.

2. **Corrige la configuración de Nginx**:
   - Edita `docker/nginx/conf.d/default.conf`
   - Cambia `proxy_set_header Host $http_host;` a `proxy_set_header Host minio:9000;`
   - Reinicia: `./scripts/stop && ./scripts/run`

3. **Verifica que los cambios se aplicaron**:
   ```bash
   docker exec <nombre-contenedor-nginx> cat /etc/nginx/conf.d/default.conf | grep "proxy_set_header Host"
   ```

**¿Por qué es necesario `minio:9000`?**
- MinIO genera firmas S3 basadas en el host `minio:9000` (configurado en el cliente)
- Si Nginx envía `Host: localhost:8000`, MinIO recalcula la firma con un host diferente
- Las firmas no coinciden → error 403
- Al reescribir a `minio:9000`, las firmas coinciden → éxito 200

**Error 3: "CORS policy: No 'Access-Control-Allow-Origin' header"**
```
Access to fetch at 'http://localhost:8000/wedding-images/...' from origin 'http://localhost:8000' has been blocked by CORS policy
```

**Causa:** Los headers CORS no se están agregando correctamente.

**Soluciones:**
1. Verifica que Nginx se haya reiniciado después de modificar la configuración
2. Verifica que la configuración de Nginx tenga `add_header ... always;` (la palabra `always` es importante)
3. Reinicia Nginx: `./scripts/stop && ./scripts/run`

**Error 4: "Upload timeout"**
```
❌ Upload timeout after 60 seconds
Error name: AbortError
```

**Causa:** La subida está tardando demasiado.

**Soluciones:**
- Intenta con una imagen más pequeña
- Verifica tu conexión a internet
- Verifica que MinIO esté respondiendo: `docker logs <nombre-contenedor-minio>`

### 6. Analizar los Logs de la Red (Network Tab)

En la pestaña Network de las DevTools, deberías ver estas solicitudes:

1. **tRPC: getImageUploadUrl**
   - Método: POST
   - URL: `http://localhost:8000/trpc/getImageUploadUrl`
   - Estado: 200
   - Respuesta: `{"uploadUrl": "http://localhost:8000/wedding-images/...", "objectName": "..."}`

2. **OPTIONS (preflight CORS)**
   - Método: OPTIONS
   - URL: `http://localhost:8000/wedding-images/hero-1234567890.jpg?X-Amz-...`
   - Estado: 204
   - Headers de respuesta deben incluir:
     - `Access-Control-Allow-Origin: *`
     - `Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS, HEAD`

3. **PUT (subida del archivo)**
   - Método: PUT
   - URL: `http://localhost:8000/wedding-images/hero-1234567890.jpg?X-Amz-...`
   - Estado: 200
   - Body: El archivo de imagen

Si alguna de estas falla:
- Haz clic en la solicitud fallida
- Ve a la pestaña "Headers" para ver los detalles de la solicitud
- Ve a la pestaña "Response" para ver el error del servidor

### 7. Verificar los Logs del Servidor

En la terminal donde ejecutaste `./scripts/run`, busca logs relacionados con la subida:

```
=== Generating presigned URL ===
Bucket: wedding-images
Object: hero-1234567890.jpg
Request host: localhost:8000
Request protocol: http
Internal URL generated: http://minio:9000/wedding-images/hero-1234567890.jpg?X-Amz-...
Public base URL: http://localhost:8000
Public upload URL: http://localhost:8000/wedding-images/hero-1234567890.jpg?X-Amz-...
✅ URL validation passed
```

Si ves errores aquí, podrían indicar:
- Problema con la conexión a MinIO desde el servidor Node.js
- Bucket no existe
- Credenciales incorrectas

### 8. Verificar Directamente con MinIO

Puedes verificar que MinIO está funcionando correctamente accediendo a su consola:

1. Abre `http://localhost:9001` en tu navegador
2. Usuario: `admin`
3. Contraseña: El valor de `ADMIN_PASSWORD` en tu archivo `.env`
4. Ve a "Buckets" → deberías ver el bucket `wedding-images`
5. Haz clic en el bucket para ver los archivos subidos

### 9. Limpiar y Reiniciar (Solución Nuclear)

Si nada de lo anterior funciona, prueba esto:

```bash
# Detener todos los servicios
./scripts/stop

# Eliminar todos los contenedores, volúmenes y redes
docker compose -f docker/compose.yaml down -v

# Esperar unos segundos
sleep 5

# Iniciar de nuevo
./scripts/run
```

**⚠️ ADVERTENCIA:** Esto eliminará TODOS los datos de la base de datos y de MinIO. Solo usa esto en desarrollo.

### 10. Verificar Variables de Entorno

Verifica que tu archivo `.env` tenga todas las variables necesarias:

```bash
cat .env
```

Deberías ver al menos:
- `ADMIN_PASSWORD=<algún-valor>`
- Otras variables específicas de tu aplicación

## Problemas Comunes Específicos

### "failed to create request" sin más detalles

Este error muy genérico puede ser causado por:

1. **Extensión del navegador bloqueando la solicitud**
   - Solución: Desactiva todas las extensiones o prueba en modo incógnito

2. **URL malformada**
   - Verifica en los logs de la consola que la URL tenga este formato:
   - `http://localhost:8000/wedding-images/hero-1234567890.jpg?X-Amz-Algorithm=...`
   - Si la URL tiene `minio:9000` o algún otro host, hay un problema en el código

3. **Protocolo mixto (HTTP/HTTPS)**
   - Si accedes a la página con HTTPS pero la URL de subida es HTTP, el navegador bloqueará la solicitud
   - Solución: Asegúrate de acceder a `http://localhost:8000` (sin 's')

4. **Puerto incorrecto**
   - La URL debe usar el puerto 8000 (Nginx), no 9000 (MinIO directo)

### El archivo se sube pero no aparece en la página

Si la subida es exitosa pero la imagen no aparece:

1. Verifica que la base de datos se actualizó:
   - Ve a `http://localhost:8000/codapt/db/`
   - Busca la tabla `SiteSettings`
   - Verifica que el campo correspondiente (`heroImageUrl`, `venueImage1Url`, o `venueImage2Url`) tenga la URL correcta

2. Verifica que la imagen sea accesible:
   - Copia la URL de la imagen de la base de datos
   - Pégala en una nueva pestaña del navegador
   - Deberías ver la imagen

3. Limpia el cache del navegador:
   - Ctrl+Shift+R (Windows/Linux) o Cmd+Shift+R (Mac)

## Información de Contacto y Depuración

Si después de seguir todos estos pasos el problema persiste, recopila la siguiente información:

1. **Logs de la consola del navegador** (pestaña Console)
2. **Logs de la red del navegador** (pestaña Network, especialmente las solicitudes fallidas)
3. **Logs del servidor** (terminal donde corre `./scripts/run`)
4. **Logs de MinIO**: `docker logs <nombre-contenedor-minio>`
5. **Logs de Nginx**: `docker logs <nombre-contenedor-nginx>`
6. **Configuración de Nginx**: `docker exec <nombre-contenedor-nginx> cat /etc/nginx/conf.d/default.conf | grep -A 10 "location /wedding-images/"`

Con esta información, será mucho más fácil identificar el problema específico.

## Resumen de la Configuración Correcta

Para referencia, esta es la configuración correcta que debe estar en su lugar:

### docker/nginx/conf.d/default.conf (location /wedding-images/)
```nginx
location /wedding-images/ {
    proxy_pass http://minio:9000/wedding-images/;
    
    # ⚠️ CRÍTICO: Debe ser "minio:9000", NO "$http_host"
    proxy_set_header Host minio:9000;
    
    # Headers CORS
    add_header 'Access-Control-Allow-Origin' '*' always;
    add_header 'Access-Control-Allow-Methods' 'GET, PUT, POST, DELETE, OPTIONS, HEAD' always;
    # ... más configuración CORS
}
```

**¿Por qué `minio:9000` y no `$http_host`?**
- MinIO genera firmas S3 usando el host interno `minio:9000`
- Si Nginx envía un host diferente (ej: `localhost:8000`), la validación de la firma falla
- Al reescribir el host a `minio:9000`, MinIO puede validar correctamente la firma

### docker/compose.yaml (servicio minio)
```yaml
environment:
  MINIO_ROOT_USER: admin
  MINIO_ROOT_PASSWORD: ${ADMIN_PASSWORD}
  # Estas variables son para la consola web de MinIO, no afectan las URLs presignadas
  MINIO_SERVER_URL: "http://localhost:8000"
  MINIO_BROWSER_REDIRECT_URL: "http://localhost:9001"
```

### src/server/minio.ts
```typescript
export const minioClient = new Client({
  endPoint: "minio",  // ← Endpoint interno de Docker
  port: 9000,
  useSSL: false,
  accessKey: "admin",
  secretKey: env.ADMIN_PASSWORD,
  pathStyle: true,
});
```

### src/server/trpc/procedures/getImageUploadUrl.ts
```typescript
// 1. Generar URL presignada con el cliente interno
const internalUrl = await minioClient.presignedPutObject(
  bucketName,
  objectName,
  60 * 60 // 1 hora
);
// Resultado: http://minio:9000/wedding-images/hero-123.jpg?X-Amz-Signature=...

// 2. Obtener la URL base pública
const publicBaseUrl = getBaseUrlFromRequest(ctx.req);
// Resultado: http://localhost:8000

// 3. Reemplazar el host interno con el público
const internalUrlObj = new URL(internalUrl);
const uploadUrl = `${publicBaseUrl}${internalUrlObj.pathname}${internalUrlObj.search}`;
// Resultado: http://localhost:8000/wedding-images/hero-123.jpg?X-Amz-Signature=...

// 4. Cuando el navegador hace PUT a esta URL:
//    - Nginx recibe: Host: localhost:8000
//    - Nginx reescribe a: Host: minio:9000
//    - MinIO valida la firma usando Host: minio:9000 ✅
```

Todos estos componentes deben trabajar juntos para que la subida funcione correctamente.
