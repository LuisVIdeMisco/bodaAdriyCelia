import { useQuery } from "@tanstack/react-query";
import { useTRPC } from "~/trpc/react";

export function WeddingHero() {
  const trpc = useTRPC();
  const settingsQuery = useQuery(trpc.getSiteSettings.queryOptions());
  
  const heroImageUrl = settingsQuery.data?.heroImageUrl || "/watercolor-archway-scene.jpg";
  
  return (
    <div className="relative h-screen w-full overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('${heroImageUrl}')`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-earth-900/50 via-earth-900/55 to-earth-900/60" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-4 text-center text-white">
        <div className="animate-fade-in space-y-6">
          {/* Names */}
          <h1 className="font-allura text-5xl tracking-[0.2em] sm:text-6xl md:text-7xl lg:text-8xl">
            <span className="block sm:inline">Adrián</span>{" "}
            <span className="block font-normal text-sage-200 sm:inline">&</span>{" "}
            <span className="block sm:inline">Celia</span>
          </h1>
          
          {/* Decorative divider */}
          <div className="mx-auto flex w-32 items-center justify-center space-x-3">
            <div className="h-px flex-1 bg-sage-200/60" />
            <div className="h-1.5 w-1.5 rotate-45 bg-sage-200/60" />
            <div className="h-px flex-1 bg-sage-200/60" />
          </div>

          {/* Wedding announcement */}
          <p className="font-serif text-xl font-light tracking-[0.2em] text-sage-100 sm:text-2xl">
            ¡Nos casamos!
          </p>

          {/* Date */}
          <p className="font-serif text-2xl font-light tracking-[0.15em] sm:text-3xl text-sage-100">
            12 de septiembre, 2026
          </p>

          {/* Venue */}
          <p className="text-lg font-light tracking-wide text-sand-100 sm:text-xl">
            Finca La Ermita de Los Llanos
          </p>
          <p className="text-base font-light tracking-wide text-sand-200 sm:text-lg">
            Arenas de San Pedro, Ávila
          </p>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 animate-bounce">
          <div className="flex flex-col items-center space-y-2 text-sage-100">
            <span className="text-xs tracking-[0.2em] font-light">DESCUBRE MÁS</span>
            <svg
              className="h-6 w-6"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="1.5"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
            </svg>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        .animate-fade-in {
          animation: fade-in 1.5s ease-out;
        }
      `}</style>
    </div>
  );
}
