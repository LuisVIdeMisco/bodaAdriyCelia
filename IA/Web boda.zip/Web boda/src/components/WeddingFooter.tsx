export function WeddingFooter() {
  return (
    <footer className="bg-earth-800 px-4 py-12 text-center">
      <div className="mx-auto max-w-4xl">
        {/* Names */}
        <p className="mb-4 font-serif text-2xl font-light tracking-wider text-sand-100">
          Adrián & Celia
        </p>

        {/* Divider */}
        <div className="mx-auto mb-4 h-px w-32 bg-earth-700" />

        {/* Message */}
        <p className="mb-2 text-sm text-sand-300">
          12 de septiembre, 2026
        </p>
        <p className="text-sm text-sand-400">
          La Ermita de Los Llanos, Arenas de San Pedro
        </p>

        {/* Copyright */}
        <p className="mt-8 text-xs text-earth-600">
          © 2026 Adrián & Celia
        </p>
      </div>
    </footer>
  );
}
