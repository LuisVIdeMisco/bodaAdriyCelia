import { Link } from "@tanstack/react-router";
import { Mail, CheckCircle2 } from "lucide-react";

export function RsvpCallToAction() {
  return (
    <section className="relative overflow-hidden px-4 py-24 sm:px-6 lg:px-8">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('/watercolor-garden-pathway-1.jpg')`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-earth-900/50 via-earth-900/55 to-earth-900/60" />
      </div>

      <div className="relative mx-auto max-w-4xl text-center">
        {/* Icon */}
        <div className="mb-6 flex justify-center">
          <div className="rounded-full bg-sage-100 p-4">
            <Mail className="h-10 w-10 text-sage-800" />
          </div>
        </div>

        {/* Heading */}
        <h2 className="mb-4 font-serif text-4xl font-light tracking-wide text-white sm:text-5xl">
          Responde a la Invitación
        </h2>

        {/* Divider */}
        <div className="mx-auto mb-6 h-px w-24 bg-sage-400" />

        {/* Description */}
        <p className="mb-10 text-lg leading-relaxed text-sand-200 sm:text-xl">
          Por favor, confirma tu asistencia o comunícanos si no podrás acompañarnos
          <br />
          antes del <span className="font-semibold text-white">1 de julio de 2026</span> para que podamos preparar todo con cariño.
        </p>

        {/* CTA Button */}
        <Link
          to="/rsvp"
          className="inline-flex items-center space-x-2 rounded-full bg-sage-600 px-10 py-4 text-lg font-semibold text-white shadow-xl transition-all hover:bg-sage-700 hover:shadow-2xl hover:scale-105"
        >
          <CheckCircle2 className="h-5 w-5" />
          <span>Responder a la Invitación</span>
        </Link>

        {/* Additional Info */}
        <p className="mt-8 text-sm text-sand-300">
          Si tienes alguna pregunta, no dudes en contactarnos:
        </p>
        <p className="mt-2 text-base font-semibold text-sage-200">
          adrianycelia2026@gmail.com
        </p>
      </div>
    </section>
  );
}
