import { ArrowUp } from "lucide-react";

export function ScrollToTopButton() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="flex justify-center py-8">
      <button
        onClick={scrollToTop}
        className="flex items-center space-x-2 rounded-full bg-sage-600 px-6 py-3 text-sm font-semibold text-white shadow-lg transition-all hover:bg-sage-700 hover:shadow-xl"
        aria-label="Volver arriba"
      >
        <ArrowUp className="h-4 w-4" />
        <span>Volver arriba</span>
      </button>
    </div>
  );
}
