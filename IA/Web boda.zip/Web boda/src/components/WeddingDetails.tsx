import { Calendar, MapPin, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useTRPC } from "~/trpc/react";

export function WeddingDetails() {
  const trpc = useTRPC();
  const settingsQuery = useQuery(trpc.getSiteSettings.queryOptions());
  
  const venueImage1Url = settingsQuery.data?.venueImage1Url || "https://images.unsplash.com/photo-1464207687429-7505649dae38?q=80&w=1200&auto=format&fit=crop";
  const venueImage2Url = settingsQuery.data?.venueImage2Url || "https://images.unsplash.com/photo-1519904981063-b0cf448d479e?q=80&w=1200&auto=format&fit=crop";
  
  return (
    <section className="bg-sand-50 px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-16 text-center">
          <h2 className="mb-4 font-serif text-4xl font-light tracking-wide text-earth-800 sm:text-5xl">
            Nuestra Celebración
          </h2>
          <div className="mx-auto h-px w-24 bg-sage-400" />
        </div>

        {/* Details Grid */}
        <div className="grid gap-8 sm:gap-12 md:grid-cols-3">
          {/* Date */}
          <div className="group text-center">
            <div className="mb-4 flex justify-center">
              <div className="rounded-full bg-sage-100 p-4 transition-transform group-hover:scale-110">
                <Calendar className="h-8 w-8 text-sage-700" />
              </div>
            </div>
            <h3 className="mb-2 text-xl font-semibold text-earth-800">Fecha</h3>
            <p className="text-earth-600">12/09/2026</p>
          </div>

          {/* Location */}
          <div className="group text-center">
            <div className="mb-4 flex justify-center">
              <div className="rounded-full bg-earth-100 p-4 transition-transform group-hover:scale-110">
                <MapPin className="h-8 w-8 text-earth-700" />
              </div>
            </div>
            <h3 className="mb-2 text-xl font-semibold text-earth-800">Lugar</h3>
            <a 
              href="https://maps.google.com/?q=Ermita+de+Los+Llanos+Arenas+de+San+Pedro" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-sage-700 underline hover:text-sage-800"
            >
              Ermita de Los Llanos
            </a>
          </div>

          {/* Time */}
          <div className="group text-center">
            <div className="mb-4 flex justify-center">
              <div className="rounded-full bg-sand-200 p-4 transition-transform group-hover:scale-110">
                <Clock className="h-8 w-8 text-sand-700" />
              </div>
            </div>
            <h3 className="mb-2 text-xl font-semibold text-earth-800">Hora</h3>
            <p className="text-earth-600">13:00h</p>
          </div>
        </div>

        {/* Additional venue images */}
        <div className="mt-20 grid gap-6 sm:grid-cols-2">
          <div 
            className="h-64 rounded-xl bg-cover bg-center shadow-lg"
            style={{
              backgroundImage: `url('${venueImage1Url}')`,
            }}
          />
          <div 
            className="h-64 rounded-xl bg-cover bg-center shadow-lg"
            style={{
              backgroundImage: `url('${venueImage2Url}')`,
            }}
          />
        </div>
      </div>
    </section>
  );
}
