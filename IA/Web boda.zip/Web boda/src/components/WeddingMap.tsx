import { Calendar, MapPin, Clock } from "lucide-react";

export function WeddingMap() {
  return (
    <section className="bg-sand-50 px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        {/* Event Details */}
        <div className="mb-12 grid gap-8 sm:gap-12 md:grid-cols-3">
          {/* Date */}
          <div className="group text-center">
            <div className="mb-4 flex justify-center">
              <div className="rounded-full bg-sage-100 p-4 transition-transform group-hover:scale-110">
                <Calendar className="h-8 w-8 text-sage-700" />
              </div>
            </div>
            <h3 className="mb-2 text-xl font-semibold text-earth-800">Fecha</h3>
            <p className="text-earth-600">12 de septiembre, 2026</p>
          </div>

          {/* Location */}
          <div className="group text-center">
            <div className="mb-4 flex justify-center">
              <div className="rounded-full bg-sage-100 p-4 transition-transform group-hover:scale-110">
                <MapPin className="h-8 w-8 text-sage-700" />
              </div>
            </div>
            <h3 className="mb-2 text-xl font-semibold text-earth-800">Lugar</h3>
            <p className="text-earth-600">La Ermita de Los Llanos</p>
            <p className="text-sm text-earth-500">Arenas de San Pedro, Ávila</p>
          </div>

          {/* Time */}
          <div className="group text-center">
            <div className="mb-4 flex justify-center">
              <div className="rounded-full bg-sage-100 p-4 transition-transform group-hover:scale-110">
                <Clock className="h-8 w-8 text-sage-700" />
              </div>
            </div>
            <h3 className="mb-2 text-xl font-semibold text-earth-800">Hora</h3>
            <p className="text-earth-600">17:30h</p>
          </div>
        </div>

        {/* Google Maps and Calendar Links */}
        <div className="text-center">
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
            <a 
              href="https://maps.google.com/?q=La+Ermita+de+Los+Llanos+Arenas+de+San+Pedro" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-sage-600 px-6 py-3 text-white transition-all hover:bg-sage-700 hover:shadow-lg"
            >
              <MapPin className="h-5 w-5" />
              <span className="font-medium">Ver en Google Maps</span>
            </a>
            <a 
              href="https://calendar.google.com/calendar/render?action=TEMPLATE&text=Boda+Adrián+y+Celia&dates=20260912T153000Z/20260912T230000Z&details=Boda+de+Adrián+y+Celia&location=La+Ermita+de+Los+Llanos,+Arenas+de+San+Pedro,+Ávila&sf=true&output=xml"
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-sage-600 px-6 py-3 text-white transition-all hover:bg-sage-700 hover:shadow-lg"
            >
              <Calendar className="h-5 w-5" />
              <span className="font-medium">Añadir a Google Calendar</span>
            </a>
          </div>
          <p className="mt-4 text-sm text-earth-500">
            Habrá servicio de autobús privado de ida y vuelta a Madrid el día de la celebración.
          </p>
        </div>
      </div>
    </section>
  );
}
