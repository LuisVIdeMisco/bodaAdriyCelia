import { Gift, Copy, Check } from "lucide-react";
import { useState } from "react";
import toast from "react-hot-toast";

export function WeddingGiftSection() {
  const [copied, setCopied] = useState(false);
  
  const accountNumber = "ES27 0081 7305 1900 0258 8869";
  
  const handleCopy = async () => {
    try {
      // Try modern clipboard API first
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(accountNumber);
        setCopied(true);
        toast.success("Número de cuenta copiado");
        setTimeout(() => setCopied(false), 2000);
      } else {
        // Fallback to older method
        const textArea = document.createElement("textarea");
        textArea.value = accountNumber;
        textArea.style.position = "fixed";
        textArea.style.left = "-999999px";
        document.body.appendChild(textArea);
        textArea.select();
        try {
          document.execCommand("copy");
          setCopied(true);
          toast.success("Número de cuenta copiado");
          setTimeout(() => setCopied(false), 2000);
        } catch (err) {
          console.error("Fallback copy failed:", err);
          toast.error("No se pudo copiar el número de cuenta");
        } finally {
          document.body.removeChild(textArea);
        }
      }
    } catch (err) {
      console.error("Failed to copy:", err);
      toast.error("No se pudo copiar el número de cuenta");
    }
  };

  return (
    <section className="bg-sand-50 px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        {/* Thank You Header */}
        <div className="mb-12 text-center">
          <div className="mb-6 flex justify-center">
            <div className="rounded-full bg-sage-100 p-4">
              <Gift className="h-10 w-10 text-sage-700" />
            </div>
          </div>
          <h2 className="mb-4 font-serif text-3xl font-light tracking-wide text-earth-800 sm:text-4xl">
            Regalos
          </h2>
          <div className="mx-auto mb-6 h-px w-24 bg-sage-400" />
        </div>

        {/* Wedding Registry Information */}
        <div className="text-center">
          <p className="text-lg leading-relaxed text-earth-600 sm:text-xl">
            Gracias por acompañarnos en este día tan especial. Si además quieres tener un detalle con nosotros, puedes elegir entre una transferencia o pedirnos que te compartamos la lista de bodas.
          </p>
          
          {/* Account Number with Copy Button */}
          <div className="mt-8 flex items-center justify-center">
            <div className="flex items-center gap-3">
              <p className="text-lg italic text-earth-700">
                {accountNumber}
              </p>
              <button
                onClick={handleCopy}
                className="flex-shrink-0 rounded-full bg-sage-100 p-2 transition-all hover:bg-sage-200 hover:scale-110"
                title={copied ? "¡Copiado!" : "Copiar número de cuenta"}
              >
                {copied ? (
                  <Check className="h-6 w-6 text-sage-700" />
                ) : (
                  <Copy className="h-6 w-6 text-sage-700" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
