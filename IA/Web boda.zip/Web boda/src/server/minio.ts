import { Client } from "minio";
import { env } from "./env";
import { getBaseUrl } from "./utils/base-url";

// Public URL for accessing MinIO through Nginx proxy (for display purposes)
export const minioBaseUrl = getBaseUrl({ port: 8000 });

// MinIO client configured with internal Docker network endpoint
// This is necessary for presigned URLs to have correct signatures
export const minioClient = new Client({
  endPoint: "minio",
  port: 9000,
  useSSL: false,
  accessKey: "admin",
  secretKey: env.ADMIN_PASSWORD,
  pathStyle: true,
});
