import type { BucketCorsConfiguration } from "minio";
import { minioClient } from "~/server/minio";
import { db } from "~/server/db";

async function setup() {
  // Create MinIO bucket for wedding images
  const bucketName = "wedding-images";
  const bucketExists = await minioClient.bucketExists(bucketName);
  
  if (!bucketExists) {
    await minioClient.makeBucket(bucketName);
    console.log(`Created bucket: ${bucketName}`);
    
    // Set bucket policy to allow public read access
    const policy = {
      Version: "2012-10-17",
      Statement: [
        {
          Effect: "Allow",
          Principal: { AWS: ["*"] },
          Action: ["s3:GetObject"],
          Resource: [`arn:aws:s3:::${bucketName}/*`],
        },
      ],
    };
    
    await minioClient.setBucketPolicy(bucketName, JSON.stringify(policy));
    console.log(`Set public read policy for bucket: ${bucketName}`);
    
    // Configure CORS for the bucket to allow PUT requests from browser
    const corsConfig: BucketCorsConfiguration = {
      CORSRules: [
        {
          AllowedOrigins: ["*"],
          AllowedMethods: ["GET", "PUT", "POST", "DELETE"],
          AllowedHeaders: ["*"],
          ExposeHeaders: ["ETag"],
          MaxAgeSeconds: 3600,
        },
      ],
    };
    
    await minioClient.setBucketCors(bucketName, corsConfig);
    console.log(`Set CORS policy for bucket: ${bucketName}`);
  }
  
  // Ensure SiteSettings record exists
  const existingSettings = await db.siteSettings.findUnique({
    where: { id: 1 },
  });
  
  const newHeroImageUrl = "/watercolor-archway-scene.jpg";
  const oldHeroImageUrl = "/cover-1.jpg";
  
  if (!existingSettings) {
    await db.siteSettings.create({
      data: {
        id: 1,
        heroImageUrl: newHeroImageUrl,
        venueImage1Url: "https://images.unsplash.com/photo-1464207687429-7505649dae38?q=80&w=1200&auto=format&fit=crop",
        venueImage2Url: "https://images.unsplash.com/photo-1519904981063-b0cf448d479e?q=80&w=1200&auto=format&fit=crop",
      },
    });
    console.log("Created default SiteSettings");
  } else if (existingSettings.heroImageUrl === oldHeroImageUrl) {
    // If settings exist but still use the old default hero image, update it
    await db.siteSettings.update({
      where: { id: 1 },
      data: {
        heroImageUrl: newHeroImageUrl,
      },
    });
    console.log(`Updated heroImageUrl from ${oldHeroImageUrl} to ${newHeroImageUrl}`);
  }
}

setup()
  .then(() => {
    console.log("setup.ts complete");
    process.exit(0);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
