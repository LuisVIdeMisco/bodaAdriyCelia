import { z } from "zod";
import { baseProcedure } from "~/server/trpc/main";
import { env } from "~/server/env";
import nodemailer from "nodemailer";

export const testEmail = baseProcedure
  .input(
    z.object({
      testEmailAddress: z.string().email("Email inválido"),
    })
  )
  .mutation(async ({ input }) => {
    const testTransporter = nodemailer.createTransport({
      host: env.SMTP_HOST,
      port: parseInt(env.SMTP_PORT),
      secure: false,
      auth: {
        user: env.SMTP_USER,
        pass: env.SMTP_PASSWORD,
      },
      tls: {
        rejectUnauthorized: false,
      },
      connectionTimeout: 10000,
      greetingTimeout: 10000,
      socketTimeout: 10000,
    });

    try {
      // First, verify the transporter configuration
      console.log("🔍 Verificando configuración SMTP...");
      console.log("Host:", env.SMTP_HOST);
      console.log("Port:", env.SMTP_PORT);
      console.log("User:", env.SMTP_USER);
      console.log("Password length:", env.SMTP_PASSWORD.length);
      console.log("Password (first 4 chars):", env.SMTP_PASSWORD.substring(0, 4) + "...");
      
      await testTransporter.verify();
      console.log("✅ Verificación SMTP exitosa");

      // Send test email
      console.log("📧 Enviando email de prueba a:", input.testEmailAddress);
      
      const info = await testTransporter.sendMail({
        from: `"Test - Adrián & Celia" <${env.SMTP_USER}>`,
        to: input.testEmailAddress,
        subject: "🧪 Email de Prueba - Sistema de Boda",
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="margin: 0; padding: 0; background-color: #fafaf9;">
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #ffffff;">
              <div style="background-color: #16a34a; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
                <h1 style="color: #ffffff; margin: 0; font-size: 24px;">✅ Email de Prueba Exitoso</h1>
              </div>
              
              <div style="padding: 20px; color: #44403c;">
                <p style="font-size: 16px; line-height: 1.6;">¡La configuración de email está funcionando correctamente!</p>
                
                <div style="background-color: #f5f5f4; padding: 15px; border-radius: 8px; margin: 20px 0;">
                  <h3 style="color: #57534e; margin-top: 0; font-size: 18px;">Detalles de la Configuración</h3>
                  <p style="margin: 5px 0; font-size: 14px;"><strong>Servidor SMTP:</strong> ${env.SMTP_HOST}</p>
                  <p style="margin: 5px 0; font-size: 14px;"><strong>Puerto:</strong> ${env.SMTP_PORT}</p>
                  <p style="margin: 5px 0; font-size: 14px;"><strong>Usuario:</strong> ${env.SMTP_USER}</p>
                  <p style="margin: 5px 0; font-size: 14px;"><strong>Fecha:</strong> ${new Date().toLocaleString("es-ES")}</p>
                </div>
                
                <p style="font-size: 14px; line-height: 1.6; color: #57534e;">
                  Este es un email de prueba del sistema de gestión de invitaciones de boda.
                  Si recibes este mensaje, significa que el servidor de correo está configurado correctamente
                  y puede enviar emails.
                </p>
              </div>
              
              <div style="text-align: center; padding: 15px; background-color: #fafaf9; border-radius: 0 0 8px 8px; border-top: 1px solid #e7e5e4;">
                <p style="margin: 0; font-size: 12px; color: #78716c;">Sistema de Gestión de Invitaciones - Boda Adrián & Celia</p>
              </div>
            </div>
          </body>
          </html>
        `,
      });

      console.log("✅ Email de prueba enviado exitosamente");
      console.log("Message ID:", info.messageId);

      return {
        success: true,
        message: "Email de prueba enviado exitosamente",
        messageId: info.messageId,
        details: {
          host: env.SMTP_HOST,
          port: env.SMTP_PORT,
          user: env.SMTP_USER,
          to: input.testEmailAddress,
        },
      };
    } catch (error) {
      console.error("❌ Error al enviar email de prueba:", error);
      
      let errorMessage = "Error desconocido";
      let errorDetails = "";
      
      if (error instanceof Error) {
        errorMessage = error.message;
        
        // Provide specific guidance based on error type
        if (errorMessage.includes("Invalid login") || errorMessage.includes("535")) {
          errorDetails = 
            "Error de autenticación SMTP. Posibles causas:\n\n" +
            "1. La contraseña de aplicación de Gmail es incorrecta\n" +
            "2. La verificación en dos pasos no está activada en la cuenta de Gmail\n" +
            "3. La contraseña de aplicación fue revocada\n\n" +
            "Solución:\n" +
            "1. Ve a https://myaccount.google.com/security\n" +
            "2. Activa la 'Verificación en dos pasos' si no está activada\n" +
            "3. Ve a https://myaccount.google.com/apppasswords\n" +
            "4. Genera una nueva contraseña de aplicación\n" +
            "5. Copia la contraseña SIN ESPACIOS\n" +
            "6. Actualiza SMTP_PASSWORD en el archivo .env\n" +
            "7. Reinicia la aplicación";
        } else if (errorMessage.includes("ECONNREFUSED") || errorMessage.includes("ETIMEDOUT")) {
          errorDetails = 
            "Error de conexión al servidor SMTP. Posibles causas:\n\n" +
            "1. Problema de red o firewall\n" +
            "2. El servidor SMTP no es accesible\n" +
            "3. El puerto está bloqueado\n\n" +
            "Verifica tu conexión a internet y configuración de firewall.";
        } else if (errorMessage.includes("ENOTFOUND")) {
          errorDetails = 
            "No se pudo resolver el nombre del servidor SMTP.\n\n" +
            "Verifica que SMTP_HOST esté configurado correctamente en .env";
        }
      }
      
      return {
        success: false,
        message: "Error al enviar email de prueba",
        error: errorMessage,
        errorDetails,
        details: {
          host: env.SMTP_HOST,
          port: env.SMTP_PORT,
          user: env.SMTP_USER,
          passwordLength: env.SMTP_PASSWORD.length,
        },
      };
    }
  });
