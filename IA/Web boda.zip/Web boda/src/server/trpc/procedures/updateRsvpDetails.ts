import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";

export const updateRsvpDetails = baseProcedure
  .input(
    z.object({
      id: z.number(),
      email: z.string().email("Email inválido").optional(),
      status: z.enum(["accepted", "declined"], {
        errorMap: () => ({ message: "Debes seleccionar aceptar o rechazar" }),
      }).optional(),
      fullName: z
        .string()
        .min(1, "El nombre completo es obligatorio")
        .refine(
          (value) => {
            const words = value.trim().split(/\s+/).filter(word => word.length > 0);
            return words.length >= 2;
          },
          {
            message: "Por favor, introduce tu nombre y al menos un apellido",
          }
        )
        .optional(),
      isAccompanied: z.boolean().optional(),
      accompaniedAdultName: z.string().optional(),
      childrenNames: z.array(z.string().min(1)).max(3, "Máximo 3 niños").optional(),
      needsBusToVenue: z.boolean().optional(),
      needsBusFromVenue: z.boolean().optional(),
      dietaryRestrictions: z
        .array(
          z.object({
            personName: z.string(),
            hasRestriction: z.boolean(),
            allergies: z.string(),
            otherRestrictions: z.string(),
          })
        )
        .optional(),
    })
  )
  .mutation(async ({ input }) => {
    // Check if RSVP exists
    const existingRsvp = await db.rsvp.findUnique({
      where: { id: input.id },
    });

    if (!existingRsvp) {
      throw new TRPCError({
        code: "NOT_FOUND",
        message: "RSVP no encontrado",
      });
    }

    // Validate dietary restrictions if provided
    if (input.dietaryRestrictions && input.dietaryRestrictions.length > 0) {
      const restrictions = input.dietaryRestrictions;
      
      // At least one person must have hasRestriction checked
      const hasAnyRestriction = restrictions.some(r => r.hasRestriction === true);
      if (!hasAnyRestriction) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Debes marcar al menos una persona con restricciones alimentarias",
        });
      }

      // For each person with hasRestriction, must have at least one field filled
      const allRestrictionsValid = restrictions.every(r => {
        if (r.hasRestriction) {
          const hasAllergies = r.allergies && r.allergies.trim() !== "";
          const hasOther = r.otherRestrictions && r.otherRestrictions.trim() !== "";
          return hasAllergies || hasOther;
        }
        return true;
      });

      if (!allRestrictionsValid) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Para cada persona marcada, debes rellenar al menos alergias o restricciones dietéticas",
        });
      }
    }

    // Prepare update data - only include fields that were provided
    const updateData: any = {};
    
    if (input.email !== undefined) updateData.email = input.email;
    if (input.status !== undefined) updateData.status = input.status;
    if (input.fullName !== undefined) updateData.fullName = input.fullName;
    if (input.isAccompanied !== undefined) updateData.isAccompanied = input.isAccompanied;
    if (input.accompaniedAdultName !== undefined) updateData.accompaniedAdultName = input.accompaniedAdultName || null;
    if (input.childrenNames !== undefined) updateData.childrenNames = input.childrenNames;
    if (input.needsBusToVenue !== undefined) updateData.needsBusToVenue = input.needsBusToVenue;
    if (input.needsBusFromVenue !== undefined) updateData.needsBusFromVenue = input.needsBusFromVenue;
    if (input.dietaryRestrictions !== undefined) updateData.dietaryRestrictions = input.dietaryRestrictions;

    // Update the RSVP in the database
    const updatedRsvp = await db.rsvp.update({
      where: { id: input.id },
      data: updateData,
    });

    return {
      success: true,
      rsvp: updatedRsvp,
    };
  });
