import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";

export const getAllRsvps = baseProcedure
  .query(async () => {
    const rsvps = await db.rsvp.findMany({
      orderBy: {
        createdAt: "desc",
      },
    });
    
    return rsvps;
  });
