import { baseProcedure } from "~/server/trpc/main";
import { getBaseUrlFromRequest } from "~/server/utils/request-url";

export const getMinioBaseUrl = baseProcedure.query(async ({ ctx }) => {
  const minioBaseUrl = getBaseUrlFromRequest(ctx.req);
  
  console.log("=== Getting MinIO base URL ===");
  console.log("Request host:", ctx.req.headers.get("host"));
  console.log("Resolved base URL:", minioBaseUrl);
  
  return { minioBaseUrl };
});
