import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";
import { sendGuestConfirmation, sendAdminReport } from "~/server/utils/email";
import { env } from "~/server/env";

export const submitRsvp = baseProcedure
  .input(
    z.object({
      email: z.string().email("Email inválido"),
      status: z.enum(["accepted", "declined"], {
        errorMap: () => ({ message: "Debes seleccionar aceptar o rechazar" }),
      }),
      fullName: z
        .string()
        .min(1, "El nombre completo es obligatorio")
        .refine(
          (value) => {
            const words = value.trim().split(/\s+/).filter(word => word.length > 0);
            return words.length >= 2;
          },
          {
            message: "Por favor, introduce tu nombre y al menos un apellido",
          }
        ),
      // Fields only required for accepted invitations
      isAccompanied: z.boolean().optional(),
      accompaniedAdultName: z.string().optional(),
      childrenNames: z.array(z.string().min(1)).max(3, "Máximo 3 niños").optional(),
      needsBusToVenue: z.boolean().optional(),
      needsBusFromVenue: z.boolean().optional(),
      hasDietaryRestrictions: z.boolean().optional(),
      dietaryRestrictions: z
        .array(
          z.object({
            personName: z.string(),
            hasRestriction: z.boolean(),
            allergies: z.string(),
            otherRestrictions: z.string(),
          })
        )
        .optional(),
    })
  )
  .mutation(async ({ input }) => {
    // Check deadline (June 30, 2026 23:59:59 Madrid time)
    const madridTime = new Date().toLocaleString("en-US", { timeZone: "Europe/Madrid" });
    const currentDateMadrid = new Date(madridTime);
    const deadline = new Date("2026-06-30T23:59:59");
    const deadlineMadrid = new Date(deadline.toLocaleString("en-US", { timeZone: "Europe/Madrid" }));

    if (currentDateMadrid > deadlineMadrid) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message:
          "Lo sentimos, el plazo para responder a la invitación ha finalizado (30 de junio de 2026).",
      });
    }

    const adminEmails = [env.ADMIN_EMAIL_1, env.ADMIN_EMAIL_2];
    const isAdminEmail = adminEmails.includes(input.email.toLowerCase());

    // Check if email already exists
    const existingRsvp = await db.rsvp.findUnique({
      where: { email: input.email },
    });

    // For non-admin emails, prevent duplicate submissions
    if (existingRsvp && !isAdminEmail) {
      throw new TRPCError({
        code: "BAD_REQUEST",
        message:
          "Este email ya ha sido utilizado para confirmar. Cada invitado solo puede responder una vez.",
      });
    }

    // For accepted invitations, validate accompanying guests
    if (input.status === "accepted" && input.isAccompanied) {
      const hasAdult = input.accompaniedAdultName && input.accompaniedAdultName.trim() !== "";
      const childrenCount = input.childrenNames?.length || 0;

      if (!hasAdult && childrenCount === 0) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Si vienes acompañado, debes indicar al menos un acompañante o niño",
        });
      }
    }

    // Validate dietary restrictions
    if (input.status === "accepted" && input.hasDietaryRestrictions) {
      const restrictions = input.dietaryRestrictions || [];
      
      // At least one person must have hasRestriction checked
      const hasAnyRestriction = restrictions.some(r => r.hasRestriction === true);
      if (!hasAnyRestriction) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Debes marcar al menos una persona con restricciones alimentarias",
        });
      }

      // For each person with hasRestriction, must have at least one field filled
      const allRestrictionsValid = restrictions.every(r => {
        if (r.hasRestriction) {
          const hasAllergies = r.allergies && r.allergies.trim() !== "";
          const hasOther = r.otherRestrictions && r.otherRestrictions.trim() !== "";
          return hasAllergies || hasOther;
        }
        return true;
      });

      if (!allRestrictionsValid) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Para cada persona marcada, debes rellenar al menos alergias o restricciones dietéticas",
        });
      }
    }

    // Prepare the RSVP data
    const rsvpData = {
      email: input.email,
      status: input.status,
      fullName: input.fullName,
      isAccompanied: input.status === "accepted" ? (input.isAccompanied || false) : false,
      accompaniedAdultName:
        input.status === "accepted" ? (input.accompaniedAdultName || null) : null,
      childrenNames: input.status === "accepted" ? (input.childrenNames || []) : [],
      needsBusToVenue: input.status === "accepted" ? (input.needsBusToVenue || false) : false,
      needsBusFromVenue:
        input.status === "accepted" ? (input.needsBusFromVenue || false) : false,
      dietaryRestrictions:
        input.status === "accepted" && input.hasDietaryRestrictions
          ? (input.dietaryRestrictions || [])
          : [],
    };

    // Create or update the RSVP in the database
    // For admin emails, use upsert to allow multiple submissions
    // For regular emails, we've already checked for duplicates above
    const rsvp = await db.rsvp.upsert({
      where: { email: input.email },
      update: rsvpData,
      create: rsvpData,
    });

    // Send confirmation email to guest
    try {
      await sendGuestConfirmation(input.email, input.fullName, input.status);
    } catch (error) {
      console.error("Error sending guest confirmation:", error);
      // Don't fail the whole operation if email fails
    }

    // Send report email to admins
    try {
      await sendAdminReport();
    } catch (error) {
      console.error("Error sending admin report:", error);
      // Don't fail the whole operation if email fails
    }

    return {
      success: true,
      rsvpId: rsvp.id,
      status: input.status,
    };
  });
