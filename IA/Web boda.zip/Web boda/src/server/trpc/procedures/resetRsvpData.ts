import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";

export const resetRsvpData = baseProcedure
  .mutation(async () => {
    // Delete all RSVP records
    const result = await db.rsvp.deleteMany({});
    
    return {
      success: true,
      deletedCount: result.count,
      message: `Se han eliminado ${result.count} registros de RSVP`,
    };
  });
