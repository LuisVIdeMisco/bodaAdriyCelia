import { z } from "zod";
import { baseProcedure } from "~/server/trpc/main";
import { db } from "~/server/db";
import { getBaseUrlFromRequest } from "~/server/utils/request-url";

export const updateSiteSettings = baseProcedure
  .input(
    z.object({
      imageType: z.enum(["hero", "venue1", "venue2"]),
      objectName: z.string(),
    })
  )
  .mutation(async ({ input, ctx }) => {
    const bucketName = "wedding-images";
    const baseUrl = getBaseUrlFromRequest(ctx.req);
    const imageUrl = `${baseUrl}/${bucketName}/${input.objectName}`;
    
    console.log("=== Updating site settings ===");
    console.log("Image type:", input.imageType);
    console.log("Object name:", input.objectName);
    console.log("Base URL:", baseUrl);
    console.log("Full image URL:", imageUrl);
    
    const updateData: Record<string, string> = {};
    
    if (input.imageType === "hero") {
      updateData.heroImageUrl = imageUrl;
    } else if (input.imageType === "venue1") {
      updateData.venueImage1Url = imageUrl;
    } else if (input.imageType === "venue2") {
      updateData.venueImage2Url = imageUrl;
    }
    
    const updatedSettings = await db.siteSettings.update({
      where: { id: 1 },
      data: updateData,
    });
    
    return updatedSettings;
  });
