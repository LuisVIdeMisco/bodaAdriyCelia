import { baseProcedure } from "~/server/trpc/main";
import { db } from "~/server/db";

export const getSiteSettings = baseProcedure.query(async () => {
  const settings = await db.siteSettings.findUnique({
    where: { id: 1 },
  });
  
  if (!settings) {
    throw new Error("Site settings not found");
  }
  
  return settings;
});
