import { z } from "zod";
import { baseProcedure } from "~/server/trpc/main";
import { minioClient } from "~/server/minio";
import { getBaseUrlFromRequest } from "~/server/utils/request-url";

export const getImageUploadUrl = baseProcedure
  .input(
    z.object({
      imageType: z.enum(["hero", "venue1", "venue2"]),
      fileExtension: z.string(),
    })
  )
  .mutation(async ({ input, ctx }) => {
    const bucketName = "wedding-images";
    const timestamp = Date.now();
    const objectName = `${input.imageType}-${timestamp}.${input.fileExtension}`;
    
    console.log("=== Generating presigned URL ===");
    console.log("Bucket:", bucketName);
    console.log("Object:", objectName);
    console.log("Request host:", ctx.req.headers.get("host"));
    console.log("Request protocol:", ctx.req.headers.get("x-forwarded-proto") || "http");
    
    // Verify bucket exists
    const bucketExists = await minioClient.bucketExists(bucketName);
    if (!bucketExists) {
      throw new Error(`Bucket ${bucketName} does not exist. Please run setup script.`);
    }
    
    // Generate presigned URL using the internal MinIO client
    // This generates a URL like: http://minio:9000/wedding-images/object?X-Amz-...
    const internalUrl = await minioClient.presignedPutObject(
      bucketName,
      objectName,
      60 * 60 // 1 hour expiration
    );
    
    console.log("Internal URL generated:", internalUrl);
    
    // Get the public base URL from the request
    const publicBaseUrl = getBaseUrlFromRequest(ctx.req);
    console.log("Public base URL:", publicBaseUrl);
    
    // Replace the internal MinIO endpoint with the public Nginx proxy URL
    // The internal URL is: http://minio:9000/wedding-images/object?X-Amz-...
    // We need to transform it to: http://localhost:8000/wedding-images/object?X-Amz-...
    // This preserves the S3 signature which is based on the path and query parameters
    const internalUrlObj = new URL(internalUrl);
    const uploadUrl = `${publicBaseUrl}${internalUrlObj.pathname}${internalUrlObj.search}`;
    
    console.log("Public upload URL:", uploadUrl);
    console.log("URL pathname:", internalUrlObj.pathname);
    console.log("URL query params:", internalUrlObj.search);
    
    // Verify the URL is valid
    try {
      const parsedUrl = new URL(uploadUrl);
      console.log("URL validation:");
      console.log("  Protocol:", parsedUrl.protocol);
      console.log("  Host:", parsedUrl.host);
      console.log("  Pathname:", parsedUrl.pathname);
      console.log("  Search params count:", parsedUrl.searchParams.size);
      
      // Verify required S3 signature parameters are present
      const requiredParams = ['X-Amz-Algorithm', 'X-Amz-Credential', 'X-Amz-Date', 'X-Amz-Signature'];
      const missingParams = requiredParams.filter(param => !parsedUrl.searchParams.has(param));
      
      if (missingParams.length > 0) {
        console.error("Missing required S3 signature parameters:", missingParams);
        throw new Error("Generated URL is missing required S3 signature parameters");
      }
      
      console.log("✅ URL validation passed");
    } catch (error) {
      console.error("❌ Invalid URL generated:", error);
      throw new Error("Failed to generate valid upload URL");
    }
    
    return {
      uploadUrl,
      objectName,
    };
  });
