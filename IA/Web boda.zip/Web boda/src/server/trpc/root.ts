import {
  createCallerFactory,
  createTRPCRouter,
  baseProcedure,
} from "~/server/trpc/main";
import { submitRsvp } from "~/server/trpc/procedures/submitRsvp";
import { getSiteSettings } from "~/server/trpc/procedures/getSiteSettings";
import { getMinioBaseUrl } from "~/server/trpc/procedures/getMinioBaseUrl";
import { getImageUploadUrl } from "~/server/trpc/procedures/getImageUploadUrl";
import { updateSiteSettings } from "~/server/trpc/procedures/updateSiteSettings";
import { testEmail } from "~/server/trpc/procedures/testEmail";
import { resetRsvpData } from "~/server/trpc/procedures/resetRsvpData";
import { getAllRsvps } from "~/server/trpc/procedures/getAllRsvps";
import { updateRsvpDetails } from "~/server/trpc/procedures/updateRsvpDetails";

export const appRouter = createTRPCRouter({
  submitRsvp,
  getSiteSettings,
  getMinioBaseUrl,
  getImageUploadUrl,
  updateSiteSettings,
  testEmail,
  resetRsvpData,
  getAllRsvps,
  updateRsvpDetails,
});

export type AppRouter = typeof appRouter;

export const createCaller = createCallerFactory(appRouter);
