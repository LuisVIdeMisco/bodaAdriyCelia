import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production"]),
  BASE_URL: z.string().optional(),
  BASE_URL_OTHER_PORT: z.string().optional(),
  ADMIN_PASSWORD: z.string(),
  
  // Email configuration
  SMTP_HOST: z.string().default("smtp.gmail.com"),
  SMTP_PORT: z.string().default("587"),
  SMTP_USER: z.string(),
  SMTP_PASSWORD: z.string(),
  ADMIN_EMAIL_1: z.string().email().default("aceciliob@gmail.com"),
  ADMIN_EMAIL_2: z.string().email().default("celvicare@gmail.com"),
  CONTACT_EMAIL: z.string().email().default("adrianycelia2026@gmail.com"),
});

export const env = envSchema.parse(process.env);
