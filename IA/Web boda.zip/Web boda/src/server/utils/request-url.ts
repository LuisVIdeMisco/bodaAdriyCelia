/**
 * Extract the base URL from the request headers
 * This allows the system to work regardless of where it's deployed
 * 
 * @param req - The HTTP request object
 * @returns The base URL (e.g., "http://localhost:8000" or "https://yourdomain.com")
 */
export function getBaseUrlFromRequest(req: Request): string {
  const host = req.headers.get("host") || "localhost:8000";
  const protocol = req.headers.get("x-forwarded-proto") || 
                   (host.includes("localhost") ? "http" : "https");
  return `${protocol}://${host}`;
}
