import nodemailer from "nodemailer";
import ExcelJS from "exceljs";
import { env } from "~/server/env";
import { db } from "~/server/db";
import { getBaseUrl } from "~/server/utils/base-url";

const transporter = nodemailer.createTransport({
  host: env.SMTP_HOST,
  port: parseInt(env.SMTP_PORT),
  secure: false, // true for 465, false for other ports
  auth: {
    user: env.SMTP_USER,
    pass: env.SMTP_PASSWORD,
  },
  tls: {
    // Do not fail on invalid certs
    rejectUnauthorized: false,
  },
  connectionTimeout: 10000, // 10 seconds
  greetingTimeout: 10000,
  socketTimeout: 10000,
});

// Verify transporter configuration on startup
transporter.verify((error, success) => {
  if (error) {
    console.error("❌ Error en la configuración del servidor de correo:", error);
    console.error("Por favor, verifica las credenciales SMTP en el archivo .env");
    console.error("Si usas Gmail, necesitas:");
    console.error("1. Activar la verificación en dos pasos");
    console.error("2. Generar una 'Contraseña de aplicación' en https://myaccount.google.com/apppasswords");
    console.error("3. Usar esa contraseña de aplicación en SMTP_PASSWORD");
  } else {
    console.log("✅ Servidor de correo configurado correctamente");
  }
});

async function generateRsvpReport(): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("RSVPs");

  // Define columns
  worksheet.columns = [
    { header: "Fecha", key: "createdAt", width: 20 },
    { header: "Email", key: "email", width: 30 },
    { header: "Estado", key: "status", width: 15 },
    { header: "Nombre Completo", key: "fullName", width: 30 },
    { header: "Viene Acompañado", key: "isAccompanied", width: 20 },
    { header: "Nombre Acompañante Adulto", key: "accompaniedAdultName", width: 30 },
    { header: "Nombres Niños", key: "childrenNames", width: 40 },
    { header: "Bus Ida", key: "needsBusToVenue", width: 15 },
    { header: "Bus Vuelta", key: "needsBusFromVenue", width: 15 },
    { header: "Restricciones Dietéticas", key: "dietaryRestrictions", width: 60 },
  ];

  // Fetch only COMPLETE RSVPs (must have a valid status)
  const rsvps = await db.rsvp.findMany({
    where: {
      status: {
        in: ["accepted", "declined"],
      },
    },
    orderBy: { createdAt: "desc" },
  });

  // Add rows
  for (const rsvp of rsvps) {
    const childrenNames = Array.isArray(rsvp.childrenNames)
      ? (rsvp.childrenNames as string[]).join(", ")
      : "";

    // Format dietary restrictions
    let dietaryRestrictionsText = "";
    if (rsvp.dietaryRestrictions) {
      try {
        const restrictions = Array.isArray(rsvp.dietaryRestrictions)
          ? rsvp.dietaryRestrictions
          : JSON.parse(rsvp.dietaryRestrictions as string);
        
        if (Array.isArray(restrictions) && restrictions.length > 0) {
          dietaryRestrictionsText = restrictions
            .map((r: { personName: string; allergies: string; otherRestrictions: string }) => {
              const parts: string[] = [];
              if (r.personName) parts.push(`${r.personName}:`);
              if (r.allergies) parts.push(`Alergias: ${r.allergies}`);
              if (r.otherRestrictions) parts.push(`Otras: ${r.otherRestrictions}`);
              return parts.join(" ");
            })
            .join(" | ");
        }
      } catch (e) {
        console.error("Error parsing dietary restrictions:", e);
      }
    }

    worksheet.addRow({
      createdAt: rsvp.createdAt.toLocaleString("es-ES"),
      email: rsvp.email,
      status: rsvp.status === "accepted" ? "Aceptada" : "Rechazada",
      fullName: rsvp.fullName,
      isAccompanied: rsvp.isAccompanied ? "Sí" : "No",
      accompaniedAdultName: rsvp.accompaniedAdultName || "",
      childrenNames,
      needsBusToVenue: rsvp.needsBusToVenue ? "Sí" : "No",
      needsBusFromVenue: rsvp.needsBusFromVenue ? "Sí" : "No",
      dietaryRestrictions: dietaryRestrictionsText,
    });
  }

  // Style header row
  worksheet.getRow(1).font = { bold: true };
  worksheet.getRow(1).fill = {
    type: "pattern",
    pattern: "solid",
    fgColor: { argb: "FFD4AF37" },
  };

  // Generate buffer
  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

export async function sendGuestConfirmation(
  email: string,
  fullName: string,
  status: "accepted" | "declined"
): Promise<void> {
  const baseUrl = getBaseUrl();
  const heroImageUrl = `${baseUrl}/watercolor-archway-scene.jpg`;
  
  const subject =
    status === "accepted"
      ? "✅ Confirmación de Asistencia - Boda Adrián y Celia"
      : "📧 Confirmación de Respuesta - Boda Adrián y Celia";

  const htmlContent =
    status === "accepted"
      ? `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="margin: 0; padding: 0; background-color: #fafaf9;">
      <div style="font-family: Georgia, serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #ffffff;">
        <!-- Header -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-image: url('${heroImageUrl}'); background-size: cover; background-position: center; border-radius: 8px 8px 0 0;">
          <tr>
            <td style="padding: 30px 20px; text-align: center; background: rgba(77, 57, 51, 0.75); border-radius: 8px 8px 0 0;">
              <h1 style="color: #ffffff; margin: 0; font-weight: 300; font-size: 32px; letter-spacing: 2px;">Adrián & Celia</h1>
              <p style="color: #e7e5e4; margin: 10px 0 0 0; font-size: 16px;">12 de septiembre, 2026</p>
            </td>
          </tr>
        </table>
        
        <!-- Content -->
        <div style="padding: 30px 20px; color: #44403c;">
          <h2 style="color: #78716c; font-weight: 400; font-size: 24px; margin-top: 0;">¡Gracias por confirmar tu asistencia!</h2>
          
          <p style="font-size: 16px; line-height: 1.6;">Hola <strong>${fullName}</strong>,</p>
          
          <p style="font-size: 16px; line-height: 1.6;">Hemos recibido tu confirmación de asistencia a nuestra boda. ¡Estamos encantados de que puedas acompañarnos en este día tan especial!</p>
          
          <!-- Event Details Box -->
          <div style="background-color: #f5f5f4; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #78716c;">
            <h3 style="color: #57534e; margin-top: 0; font-size: 18px;">📅 Detalles del Evento</h3>
            <p style="margin: 8px 0; font-size: 15px;"><strong>Fecha:</strong> Viernes, 12 de septiembre de 2026</p>
            <p style="margin: 8px 0; font-size: 15px;"><strong>Hora de la ceremonia:</strong> 17:30h</p>
            <p style="margin: 8px 0; font-size: 15px;"><strong>Lugar:</strong> Finca La Ermita de Los Llanos</p>
            <p style="margin: 8px 0; font-size: 15px;"><strong>Ubicación:</strong> Arenas de San Pedro, Ávila (Sierra de Gredos)</p>
          </div>
          
          <!-- Important Info Box -->
          <div style="background-color: #fef3c7; padding: 20px; border-radius: 8px; margin: 25px 0; border-left: 4px solid #f59e0b;">
            <h3 style="color: #92400e; margin-top: 0; font-size: 18px;">ℹ️ Información Importante</h3>
            <p style="margin: 8px 0; font-size: 15px; color: #78350f;">Te enviaremos más detalles sobre el evento, incluyendo:</p>
            <ul style="margin: 10px 0; padding-left: 20px; color: #78350f;">
              <li style="margin: 5px 0;">Detalles del servicio de autobús desde Madrid.</li>
              <li style="margin: 5px 0;">Programación del día</li>
            </ul>
          </div>
          
          <p style="font-size: 16px; line-height: 1.6; margin-top: 25px;">Si tienes alguna pregunta o necesitas modificar tu respuesta, no dudes en contactarnos en <a href="mailto:adrianycelia2026@gmail.com" style="color: #78716c; text-decoration: none; font-weight: bold;">adrianycelia2026@gmail.com</a></p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-top: 30px; font-style: italic; color: #57534e;">¡Estamos deseando celebrar este día tan especial contigo!</p>
          
          <p style="margin-top: 30px; font-size: 16px;">Con cariño,<br/><strong>Adrián y Celia</strong></p>
        </div>
        
        <!-- Footer -->
        <div style="text-align: center; padding: 20px; background-color: #fafaf9; border-radius: 0 0 8px 8px; border-top: 1px solid #e7e5e4;">
          <p style="margin: 0; font-size: 12px; color: #78716c;">Boda Adrián & Celia • 12 de septiembre, 2026</p>
          <p style="margin: 5px 0 0 0; font-size: 12px; color: #78716c;">Finca La Ermita de Los Llanos, Ávila</p>
        </div>
      </div>
    </body>
    </html>
  `
      : `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="margin: 0; padding: 0; background-color: #fafaf9;">
      <div style="font-family: Georgia, serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #ffffff;">
        <!-- Header -->
        <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-image: url('${heroImageUrl}'); background-size: cover; background-position: center; border-radius: 8px 8px 0 0;">
          <tr>
            <td style="padding: 30px 20px; text-align: center; background: rgba(77, 57, 51, 0.75); border-radius: 8px 8px 0 0;">
              <h1 style="color: #ffffff; margin: 0; font-weight: 300; font-size: 32px; letter-spacing: 2px;">Adrián & Celia</h1>
              <p style="color: #e7e5e4; margin: 10px 0 0 0; font-size: 16px;">12 de septiembre, 2026</p>
            </td>
          </tr>
        </table>
        
        <!-- Content -->
        <div style="padding: 30px 20px; color: #44403c;">
          <h2 style="color: #78716c; font-weight: 400; font-size: 24px; margin-top: 0;">Gracias por tu respuesta</h2>
          
          <p style="font-size: 16px; line-height: 1.6;">Hola <strong>${fullName}</strong>,</p>
          
          <p style="font-size: 16px; line-height: 1.6;">Hemos recibido tu respuesta. Lamentamos mucho que no puedas acompañarnos en nuestra boda, pero te agradecemos enormemente que nos lo hayas comunicado.</p>
          
          <p style="font-size: 16px; line-height: 1.6;">Tu presencia será echada de menos, pero esperamos poder celebrar contigo en otra ocasión.</p>
          
          <p style="font-size: 16px; line-height: 1.6; margin-top: 25px;">Si cambias de opinión o tienes alguna pregunta, no dudes en contactarnos en <a href="mailto:adrianycelia2026@gmail.com" style="color: #78716c; text-decoration: none; font-weight: bold;">adrianycelia2026@gmail.com</a></p>
          
          <p style="margin-top: 30px; font-size: 16px;">Con cariño,<br/><strong>Adrián y Celia</strong></p>
        </div>
        
        <!-- Footer -->
        <div style="text-align: center; padding: 20px; background-color: #fafaf9; border-radius: 0 0 8px 8px; border-top: 1px solid #e7e5e4;">
          <p style="margin: 0; font-size: 12px; color: #78716c;">Boda Adrián & Celia • 12 de septiembre, 2026</p>
          <p style="margin: 5px 0 0 0; font-size: 12px; color: #78716c;">Finca La Ermita de Los Llanos, Ávila</p>
        </div>
      </div>
    </body>
    </html>
  `;

  try {
    const info = await transporter.sendMail({
      from: `"Adrián & Celia" <${env.SMTP_USER}>`,
      to: email,
      subject,
      html: htmlContent,
    });
    
    console.log(`✅ Correo de confirmación enviado a ${email} (Message ID: ${info.messageId})`);
  } catch (error) {
    console.error(`❌ Error al enviar correo de confirmación a ${email}:`, error);
    throw error;
  }
}

export async function sendAdminReport(): Promise<void> {
  const reportBuffer = await generateRsvpReport();
  const date = new Date().toLocaleDateString("es-ES");
  const time = new Date().toLocaleTimeString("es-ES");

  // Get summary statistics (only from complete responses)
  const rsvps = await db.rsvp.findMany({
    where: {
      status: {
        in: ["accepted", "declined"],
      },
    },
  });
  const acceptedCount = rsvps.filter(r => r.status === "accepted").length;
  const declinedCount = rsvps.filter(r => r.status === "declined").length;
  
  // Calculate guest counts
  let totalGuests = 0;
  let accompaniedAdultsCount = 0;
  let childrenCount = 0;
  
  rsvps.forEach(rsvp => {
    if (rsvp.status !== "accepted") return;
    
    // Count the main guest
    totalGuests += 1;
    
    // Count accompanied adult
    if (rsvp.isAccompanied && rsvp.accompaniedAdultName) {
      accompaniedAdultsCount += 1;
      totalGuests += 1;
    }
    
    // Count children
    const children = (rsvp.childrenNames as string[]) || [];
    childrenCount += children.length;
    totalGuests += children.length;
  });
  
  const totalAccompanied = accompaniedAdultsCount + childrenCount;

  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="margin: 0; padding: 0; background-color: #fafaf9;">
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #ffffff;">
        <div style="background-color: #78716c; padding: 20px; border-radius: 8px 8px 0 0; text-align: center;">
          <h1 style="color: #ffffff; margin: 0; font-size: 24px;">📊 Nueva Respuesta de Invitación</h1>
        </div>
        
        <div style="padding: 20px; color: #44403c;">
          <p style="font-size: 16px; line-height: 1.6;">Se ha recibido una nueva respuesta para la boda.</p>
          
          <div style="background-color: #f5f5f4; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #57534e; margin-top: 0; font-size: 18px;">Resumen de Respuestas</h3>
            <p style="margin: 5px 0; font-size: 15px; color: #2563eb;"><strong>👥 Total de invitados confirmados:</strong> ${totalGuests}</p>
            <p style="margin: 5px 0; font-size: 15px; color: #16a34a;"><strong>✅ Número de invitados directos:</strong> ${acceptedCount}</p>
            <p style="margin: 5px 0; font-size: 15px; color: #8b5cf6;"><strong>👫 Número de acompañantes:</strong> ${totalAccompanied}</p>
            <p style="margin: 5px 0; font-size: 15px; color: #f59e0b;"><strong>👶 Número de niños:</strong> ${childrenCount}</p>
            <p style="margin: 5px 0; font-size: 15px; color: #dc2626;"><strong>❌ Número de personas que no asistirán:</strong> ${declinedCount}</p>
          </div>
          
          <p style="font-size: 16px; line-height: 1.6;">Adjunto encontrarás el reporte actualizado en formato Excel con todas las respuestas recibidas hasta el momento, incluyendo:</p>
          <ul style="font-size: 15px; line-height: 1.8; color: #57534e;">
            <li>Información de contacto</li>
            <li>Estado de confirmación</li>
            <li>Acompañantes y niños</li>
            <li>Necesidades de transporte (autobús)</li>
            <li>Restricciones alimentarias</li>
          </ul>
          
          <div style="background-color: #fef3c7; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b;">
            <p style="margin: 0; font-size: 14px; color: #78350f;">
              <strong>📅 Fecha y hora del reporte:</strong> ${date} a las ${time}
            </p>
          </div>
        </div>
        
        <div style="text-align: center; padding: 15px; background-color: #fafaf9; border-radius: 0 0 8px 8px; border-top: 1px solid #e7e5e4;">
          <p style="margin: 0; font-size: 12px; color: #78716c;">Sistema de Gestión de Invitaciones - Boda Adrián & Celia</p>
        </div>
      </div>
    </body>
    </html>
  `;

  try {
    const info = await transporter.sendMail({
      from: `"Sistema Boda A&C" <${env.SMTP_USER}>`,
      to: env.CONTACT_EMAIL,
      subject: `📊 Nueva Respuesta - Reporte Asistencia Boda A&C (${totalGuests} invitados confirmados)`,
      html: htmlContent,
      attachments: [
        {
          filename: `Reporte_Asistencia_Boda_${date.replace(/\//g, "-")}.xlsx`,
          content: reportBuffer,
        },
      ],
    });
    
    console.log(`✅ Reporte administrativo enviado a ${env.CONTACT_EMAIL} (Message ID: ${info.messageId})`);
  } catch (error) {
    console.error(`❌ Error al enviar reporte administrativo:`, error);
    throw error;
  }
}
