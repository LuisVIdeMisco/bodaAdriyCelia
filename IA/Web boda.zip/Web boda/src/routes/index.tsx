import { createFileRoute } from "@tanstack/react-router";
import { WeddingHero } from "~/components/WeddingHero";
import { WeddingMap } from "~/components/WeddingMap";
import { RsvpCallToAction } from "~/components/RsvpCallToAction";
import { WeddingGiftSection } from "~/components/WeddingGiftSection";
import { ScrollToTopButton } from "~/components/ScrollToTopButton";
import { WeddingFooter } from "~/components/WeddingFooter";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <div className="min-h-screen">
      <WeddingHero />
      <WeddingMap />
      <RsvpCallToAction />
      <WeddingGiftSection />
      <ScrollToTopButton />
      <WeddingFooter />
    </div>
  );
}
