import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useTRPC } from "~/trpc/react";
import { Edit, Users, CheckCircle, XCircle, Bus, UtensilsCrossed, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/admin/rsvps/")({
  component: AdminRsvpsListPage,
});

function AdminRsvpsListPage() {
  const trpc = useTRPC();
  const rsvpsQuery = useQuery(trpc.getAllRsvps.queryOptions());
  
  if (rsvpsQuery.isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-sand-50">
        <div className="text-lg text-earth-600">Cargando RSVPs...</div>
      </div>
    );
  }
  
  if (rsvpsQuery.isError) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-sand-50">
        <div className="text-lg text-red-600">Error al cargar los RSVPs</div>
      </div>
    );
  }
  
  const rsvps = rsvpsQuery.data || [];
  const acceptedCount = rsvps.filter(r => r.status === "accepted").length;
  const declinedCount = rsvps.filter(r => r.status === "declined").length;
  
  // Calculate total guests (including main guest, adult companion, and children)
  const totalGuests = rsvps.reduce((total, rsvp) => {
    if (rsvp.status !== "accepted") return total;
    let count = 1; // Main guest
    if (rsvp.accompaniedAdultName) count += 1;
    const childrenNames = Array.isArray(rsvp.childrenNames) ? rsvp.childrenNames : [];
    count += childrenNames.length;
    return total + count;
  }, 0);
  
  return (
    <div className="min-h-screen bg-sand-50 px-4 py-12 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <Link
            to="/admin"
            className="mb-4 inline-flex items-center space-x-2 text-sm text-sage-700 transition-colors hover:text-sage-800"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Volver a Administración</span>
          </Link>
          
          <h1 className="mb-4 font-serif text-4xl font-light tracking-wide text-earth-800 sm:text-5xl">
            Gestión de RSVPs
          </h1>
          <div className="mx-auto h-px w-24 bg-sage-400" />
          
          {/* Stats */}
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="rounded-lg bg-white p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-earth-600">Total Respuestas</p>
                  <p className="text-2xl font-semibold text-earth-800">{rsvps.length}</p>
                </div>
                <Users className="h-8 w-8 text-sage-600" />
              </div>
            </div>
            
            <div className="rounded-lg bg-white p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-earth-600">Confirmados</p>
                  <p className="text-2xl font-semibold text-green-600">{acceptedCount}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
            </div>
            
            <div className="rounded-lg bg-white p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-earth-600">Total Invitados</p>
                  <p className="text-2xl font-semibold text-sage-700">{totalGuests}</p>
                </div>
                <Users className="h-8 w-8 text-sage-700" />
              </div>
            </div>
          </div>
        </div>
        
        {/* RSVPs Table */}
        <div className="overflow-hidden rounded-lg bg-white shadow-md">
          {rsvps.length === 0 ? (
            <div className="p-12 text-center">
              <p className="text-lg text-earth-600">No hay RSVPs todavía</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-sand-200">
                <thead className="bg-sage-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-earth-700">
                      Nombre
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-earth-700">
                      Email
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-earth-700">
                      Estado
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-earth-700">
                      Invitados
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-semibold uppercase tracking-wider text-earth-700">
                      Detalles
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-semibold uppercase tracking-wider text-earth-700">
                      Acciones
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-sand-200 bg-white">
                  {rsvps.map((rsvp) => {
                    const childrenNames = Array.isArray(rsvp.childrenNames) ? rsvp.childrenNames : [];
                    const guestCount = rsvp.status === "accepted" 
                      ? 1 + (rsvp.accompaniedAdultName ? 1 : 0) + childrenNames.length
                      : 0;
                    const dietaryRestrictions = Array.isArray(rsvp.dietaryRestrictions) ? rsvp.dietaryRestrictions : [];
                    const hasDietaryRestrictions = dietaryRestrictions.length > 0;
                    
                    return (
                      <tr key={rsvp.id} className="hover:bg-sand-50">
                        <td className="whitespace-nowrap px-6 py-4">
                          <div className="font-medium text-earth-800">{rsvp.fullName}</div>
                        </td>
                        <td className="whitespace-nowrap px-6 py-4">
                          <div className="text-sm text-earth-600">{rsvp.email || "—"}</div>
                        </td>
                        <td className="whitespace-nowrap px-6 py-4">
                          {rsvp.status === "accepted" ? (
                            <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-800">
                              <CheckCircle className="h-3 w-3" />
                              Confirmado
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 rounded-full bg-red-100 px-3 py-1 text-xs font-semibold text-red-800">
                              <XCircle className="h-3 w-3" />
                              Rechazado
                            </span>
                          )}
                        </td>
                        <td className="whitespace-nowrap px-6 py-4">
                          <div className="flex items-center gap-1 text-sm text-earth-700">
                            <Users className="h-4 w-4" />
                            <span>{guestCount}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex gap-2">
                            {rsvp.needsBusToVenue && (
                              <span className="inline-flex items-center gap-1 rounded bg-blue-100 px-2 py-1 text-xs text-blue-800" title="Bus de ida">
                                <Bus className="h-3 w-3" />
                                Ida
                              </span>
                            )}
                            {rsvp.needsBusFromVenue && (
                              <span className="inline-flex items-center gap-1 rounded bg-blue-100 px-2 py-1 text-xs text-blue-800" title="Bus de vuelta">
                                <Bus className="h-3 w-3" />
                                Vuelta
                              </span>
                            )}
                            {hasDietaryRestrictions && (
                              <span className="inline-flex items-center gap-1 rounded bg-orange-100 px-2 py-1 text-xs text-orange-800" title="Restricciones dietéticas">
                                <UtensilsCrossed className="h-3 w-3" />
                                Dieta
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="whitespace-nowrap px-6 py-4 text-right">
                          <Link
                            to="/admin/rsvps/$rsvpId"
                            params={{ rsvpId: String(rsvp.id) }}
                            className="inline-flex items-center gap-2 rounded-lg bg-sage-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-sage-700"
                          >
                            <Edit className="h-4 w-4" />
                            Editar
                          </Link>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
