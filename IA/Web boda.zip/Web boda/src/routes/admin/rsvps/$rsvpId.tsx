import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useTRPC } from "~/trpc/react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import toast from "react-hot-toast";
import { ArrowLeft, Plus, X, Save, CheckCircle, XCircle } from "lucide-react";
import React from "react";

export const Route = createFileRoute("/admin/rsvps/$rsvpId")({
  component: AdminRsvpEditPage,
});

const rsvpEditSchema = z
  .object({
    email: z.string().email("Por favor, introduce un email válido").optional(),
    status: z.enum(["accepted", "declined"], {
      errorMap: () => ({ message: "Debes seleccionar una opción" }),
    }),
    fullName: z
      .string()
      .min(1, "El nombre completo es obligatorio")
      .refine(
        (value) => {
          const words = value.trim().split(/\s+/).filter(word => word.length > 0);
          return words.length >= 2;
        },
        {
          message: "Por favor, introduce tu nombre y al menos un apellido",
        }
      ),
    isAccompanied: z.boolean().optional(),
    accompaniedAdultName: z.string().optional(),
    children: z
      .array(
        z.object({
          name: z.string().min(1, "El nombre del niño/a es obligatorio"),
        })
      )
      .max(3, "Máximo 3 niños")
      .optional(),
    needsBusToVenue: z.boolean().optional(),
    needsBusFromVenue: z.boolean().optional(),
    hasDietaryRestrictions: z.boolean().optional(),
    dietaryRestrictions: z
      .array(
        z.object({
          personName: z.string(),
          hasRestriction: z.boolean(),
          allergies: z.string(),
          otherRestrictions: z.string(),
        })
      )
      .optional(),
  })
  .refine(
    (data) => {
      if (data.status === "accepted" && data.isAccompanied) {
        const hasAdult = data.accompaniedAdultName && data.accompaniedAdultName.trim() !== "";
        const hasChildren = data.children && data.children.length > 0;
        return hasAdult || hasChildren;
      }
      return true;
    },
    {
      message: "Si vienes acompañado, debes indicar al menos un acompañante adulto o niño/a",
      path: ["isAccompanied"],
    }
  )
  .refine(
    (data) => {
      // If has dietary restrictions, at least one person must have hasRestriction checked
      if (data.status === "accepted" && data.hasDietaryRestrictions) {
        const restrictions = data.dietaryRestrictions || [];
        return restrictions.some(r => r.hasRestriction === true);
      }
      return true;
    },
    {
      message: "Debes marcar al menos una persona con restricciones alimentarias",
      path: ["hasDietaryRestrictions"],
    }
  )
  .refine(
    (data) => {
      // For each person with hasRestriction true, must have at least one field filled
      if (data.status === "accepted" && data.hasDietaryRestrictions) {
        const restrictions = data.dietaryRestrictions || [];
        return restrictions.every(r => {
          if (r.hasRestriction) {
            const hasAllergies = r.allergies && r.allergies.trim() !== "";
            const hasOther = r.otherRestrictions && r.otherRestrictions.trim() !== "";
            return hasAllergies || hasOther;
          }
          return true;
        });
      }
      return true;
    },
    {
      message: "Para cada persona marcada, debes rellenar al menos alergias o restricciones dietéticas",
      path: ["dietaryRestrictions"],
    }
  );

type RsvpEditFormData = z.infer<typeof rsvpEditSchema>;

function AdminRsvpEditPage() {
  const { rsvpId } = Route.useParams();
  const router = useRouter();
  const trpc = useTRPC();
  
  const rsvpsQuery = useQuery(trpc.getAllRsvps.queryOptions());
  const updateRsvpMutation = useMutation(trpc.updateRsvpDetails.mutationOptions());
  
  // Find the specific RSVP
  const rsvp = rsvpsQuery.data?.find(r => r.id === Number(rsvpId));
  
  const {
    register,
    handleSubmit,
    watch,
    control,
    setValue,
    reset,
    formState: { errors },
  } = useForm<RsvpEditFormData>({
    resolver: zodResolver(rsvpEditSchema),
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "children",
  });

  // Initialize form with RSVP data
  React.useEffect(() => {
    if (rsvp) {
      const childrenNames = Array.isArray(rsvp.childrenNames) ? rsvp.childrenNames : [];
      const dietaryRestrictions = Array.isArray(rsvp.dietaryRestrictions) ? rsvp.dietaryRestrictions : [];
      
      // Ensure hasRestriction field exists and is set based on whether there are any restrictions
      const processedRestrictions = dietaryRestrictions.map((r: any) => ({
        personName: r.personName || "",
        hasRestriction: r.hasRestriction !== undefined ? r.hasRestriction : !!(r.allergies || r.otherRestrictions),
        allergies: r.allergies || "",
        otherRestrictions: r.otherRestrictions || "",
      }));
      
      reset({
        email: rsvp.email || "",
        status: rsvp.status as "accepted" | "declined" | undefined,
        fullName: rsvp.fullName,
        isAccompanied: rsvp.isAccompanied,
        accompaniedAdultName: rsvp.accompaniedAdultName || "",
        children: childrenNames.map(name => ({ name })),
        needsBusToVenue: rsvp.needsBusToVenue,
        needsBusFromVenue: rsvp.needsBusFromVenue,
        hasDietaryRestrictions: processedRestrictions.length > 0 && processedRestrictions.some((r: any) => r.hasRestriction),
        dietaryRestrictions: processedRestrictions,
      });
    }
  }, [rsvp, reset]);

  const status = watch("status");
  const isAccompanied = watch("isAccompanied");
  const hasDietaryRestrictions = watch("hasDietaryRestrictions");
  const fullName = watch("fullName");
  const accompaniedAdultName = watch("accompaniedAdultName");
  const children = watch("children");
  const dietaryRestrictions = watch("dietaryRestrictions") || [];

  // Helper function to get all person names
  const getAllPersonNames = (): string[] => {
    const names: string[] = [];
    if (fullName && fullName.trim()) {
      names.push(fullName.trim());
    }
    if (isAccompanied && accompaniedAdultName && accompaniedAdultName.trim()) {
      names.push(accompaniedAdultName.trim());
    }
    if (isAccompanied && children && children.length > 0) {
      children.forEach((child) => {
        if (child.name && child.name.trim()) {
          names.push(child.name.trim());
        }
      });
    }
    return names;
  };

  // Update dietary restrictions when person names change
  React.useEffect(() => {
    if (status === "accepted" && hasDietaryRestrictions) {
      const allNames = getAllPersonNames();
      const currentRestrictions = dietaryRestrictions || [];
      
      const currentNames = currentRestrictions.map(r => r.personName);
      const namesChanged = 
        allNames.length !== currentNames.length ||
        allNames.some((name, i) => name !== currentNames[i]);
      
      if (namesChanged) {
        const restrictionsMap = new Map(
          currentRestrictions.map((r) => [r.personName, r])
        );
        
        const newRestrictions = allNames.map((name) => {
          const existing = restrictionsMap.get(name);
          return existing || {
            personName: name,
            hasRestriction: false,
            allergies: "",
            otherRestrictions: "",
          };
        });
        
        setValue("dietaryRestrictions", newRestrictions);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, hasDietaryRestrictions, fullName, accompaniedAdultName, children, setValue]);

  const onSubmit = async (data: RsvpEditFormData) => {
    const updatePromise = updateRsvpMutation.mutateAsync({
      id: Number(rsvpId),
      email: data.email,
      status: data.status,
      fullName: data.fullName,
      isAccompanied: data.status === "accepted" ? data.isAccompanied : false,
      accompaniedAdultName:
        data.status === "accepted" ? data.accompaniedAdultName : undefined,
      childrenNames:
        data.status === "accepted" && data.children
          ? data.children.map((c) => c.name)
          : [],
      needsBusToVenue: data.status === "accepted" ? data.needsBusToVenue : false,
      needsBusFromVenue: data.status === "accepted" ? data.needsBusFromVenue : false,
      dietaryRestrictions:
        data.status === "accepted" && data.hasDietaryRestrictions
          ? data.dietaryRestrictions
          : [],
    });

    await toast.promise(updatePromise, {
      loading: "Guardando cambios...",
      success: "¡RSVP actualizado correctamente!",
      error: (err) => err.message || "Error al guardar. Por favor, inténtalo de nuevo.",
    });

    // Invalidate queries to refresh data
    await rsvpsQuery.refetch();
    
    // Navigate back to list
    setTimeout(() => {
      router.navigate({ to: "/admin/rsvps" });
    }, 1500);
  };

  if (rsvpsQuery.isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-sand-50">
        <div className="text-lg text-earth-600">Cargando...</div>
      </div>
    );
  }

  if (rsvpsQuery.isError || !rsvp) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-sand-50">
        <div className="text-center">
          <div className="mb-4 text-lg text-red-600">
            {rsvpsQuery.isError ? "Error al cargar el RSVP" : "RSVP no encontrado"}
          </div>
          <Link
            to="/admin/rsvps"
            className="text-sage-700 underline hover:text-sage-800"
          >
            Volver a la lista
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-sand-50 px-4 py-12 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-3xl">
        {/* Header */}
        <div className="mb-8">
          <Link
            to="/admin/rsvps"
            className="mb-4 inline-flex items-center space-x-2 text-sm text-sage-700 transition-colors hover:text-sage-800"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Volver a la lista</span>
          </Link>
          
          <h1 className="mb-4 font-serif text-4xl font-light tracking-wide text-earth-800 sm:text-5xl">
            Editar RSVP
          </h1>
          <div className="h-px w-24 bg-sage-400" />
          <p className="mt-4 text-earth-600">
            Modificando respuesta de {rsvp.fullName}
          </p>
        </div>

        {/* Form */}
        <div className="overflow-hidden rounded-2xl bg-white shadow-xl">
          <div className="p-6 sm:p-12">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
              {/* Email */}
              <div>
                <label
                  htmlFor="email"
                  className="mb-2 block text-sm font-semibold text-earth-700"
                >
                  Email:
                </label>
                <input
                  id="email"
                  type="email"
                  {...register("email")}
                  className="w-full rounded-lg border-sand-300 px-4 py-3 focus:border-sage-500 focus:ring-sage-500"
                  placeholder="email@ejemplo.com"
                />
                {errors.email && (
                  <p className="mt-2 text-sm text-red-600">{errors.email.message}</p>
                )}
              </div>

              {/* Status Selection */}
              <div className="rounded-lg border-2 border-sage-200 bg-sage-50 p-6">
                <label className="mb-4 block text-base font-semibold text-earth-800">
                  Estado de asistencia: *
                </label>
                <div className="space-y-3">
                  <label className="flex cursor-pointer items-start rounded-lg border-2 border-sand-200 bg-white p-4 transition-all hover:border-sage-400 has-[:checked]:border-sage-600 has-[:checked]:bg-sage-50">
                    <input
                      type="radio"
                      value="accepted"
                      {...register("status")}
                      className="mt-1 h-5 w-5 border-sand-300 text-sage-600 focus:ring-sage-500"
                    />
                    <div className="ml-3">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-5 w-5 text-sage-600" />
                        <span className="font-semibold text-earth-800">
                          Confirmado
                        </span>
                      </div>
                    </div>
                  </label>

                  <label className="flex cursor-pointer items-start rounded-lg border-2 border-sand-200 bg-white p-4 transition-all hover:border-earth-400 has-[:checked]:border-earth-600 has-[:checked]:bg-earth-50">
                    <input
                      type="radio"
                      value="declined"
                      {...register("status")}
                      className="mt-1 h-5 w-5 border-sand-300 text-earth-600 focus:ring-earth-500"
                    />
                    <div className="ml-3">
                      <div className="flex items-center space-x-2">
                        <XCircle className="h-5 w-5 text-earth-600" />
                        <span className="font-semibold text-earth-800">
                          Rechazado
                        </span>
                      </div>
                    </div>
                  </label>
                </div>
                {errors.status && (
                  <p className="mt-3 text-sm text-red-600">{errors.status.message}</p>
                )}
              </div>

              {/* Full Name */}
              <div>
                <label
                  htmlFor="fullName"
                  className="mb-2 block text-sm font-semibold text-earth-700"
                >
                  Nombre completo: *
                </label>
                <input
                  id="fullName"
                  type="text"
                  {...register("fullName")}
                  className="w-full rounded-lg border-sand-300 px-4 py-3 focus:border-sage-500 focus:ring-sage-500"
                  placeholder="Nombre completo"
                />
                {errors.fullName && (
                  <p className="mt-2 text-sm text-red-600">{errors.fullName.message}</p>
                )}
              </div>

              {/* Only show additional fields if accepted */}
              {status === "accepted" && (
                <>
                  {/* Is Accompanied */}
                  <div className="rounded-lg bg-sage-50 p-6">
                    <div className="flex items-start">
                      <div className="flex h-6 items-center">
                        <input
                          id="isAccompanied"
                          type="checkbox"
                          {...register("isAccompanied")}
                          className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                        />
                      </div>
                      <div className="ml-3">
                        <label
                          htmlFor="isAccompanied"
                          className="font-semibold text-earth-700"
                        >
                          Viene acompañado/a
                        </label>
                      </div>
                    </div>

                    {/* Accompanied Guests */}
                    {isAccompanied && (
                      <div className="mt-6 space-y-6">
                        {/* Adult Companion */}
                        <div>
                          <label
                            htmlFor="accompaniedAdultName"
                            className="mb-2 block text-sm font-semibold text-earth-700"
                          >
                            Acompañante adulto:
                          </label>
                          <input
                            id="accompaniedAdultName"
                            type="text"
                            {...register("accompaniedAdultName")}
                            className="w-full rounded-lg border-sand-300 px-4 py-3 focus:border-sage-500 focus:ring-sage-500"
                            placeholder="Nombre completo"
                          />
                        </div>

                        {/* Children */}
                        <div>
                          <div className="mb-3 flex items-center justify-between">
                            <label className="text-sm font-semibold text-earth-700">
                              Niños/as:
                            </label>
                            {fields.length < 3 && (
                              <button
                                type="button"
                                onClick={() => append({ name: "" })}
                                className="flex items-center space-x-1 rounded-lg bg-sage-600 px-3 py-2 text-sm font-semibold text-white transition-colors hover:bg-sage-700"
                              >
                                <Plus className="h-4 w-4" />
                                <span>Añadir niño/a</span>
                              </button>
                            )}
                          </div>

                          {fields.length === 0 && (
                            <p className="text-sm italic text-earth-500">
                              Haz clic en "Añadir niño/a" si viene con niños
                            </p>
                          )}

                          <div className="space-y-3">
                            {fields.map((field, index) => (
                              <div key={field.id} className="flex items-start space-x-3">
                                <div className="flex-1">
                                  <input
                                    type="text"
                                    {...register(`children.${index}.name`)}
                                    className="w-full rounded-lg border-sand-300 px-4 py-3 focus:border-sage-500 focus:ring-sage-500"
                                    placeholder={`Nombre del niño/a ${index + 1}`}
                                  />
                                  {errors.children?.[index]?.name && (
                                    <p className="mt-1 text-sm text-red-600">
                                      {errors.children[index]?.name?.message}
                                    </p>
                                  )}
                                </div>
                                <button
                                  type="button"
                                  onClick={() => remove(index)}
                                  className="mt-3 rounded-lg bg-red-100 p-2 text-red-600 transition-colors hover:bg-red-200"
                                >
                                  <X className="h-5 w-5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                    {errors.isAccompanied && (
                      <p className="mt-3 text-sm text-red-600">
                        {errors.isAccompanied.message}
                      </p>
                    )}
                  </div>

                  {/* Bus Service */}
                  <div className="rounded-lg border-2 border-sage-200 p-6">
                    <h3 className="mb-4 text-lg font-semibold text-earth-800">
                      Servicio de autobús:
                    </h3>

                    <div className="space-y-3">
                      <div className="flex items-start">
                        <div className="flex h-6 items-center">
                          <input
                            id="needsBusToVenue"
                            type="checkbox"
                            {...register("needsBusToVenue")}
                            className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                          />
                        </div>
                        <div className="ml-3">
                          <label
                            htmlFor="needsBusToVenue"
                            className="font-medium text-earth-700"
                          >
                            Bus de ida
                          </label>
                        </div>
                      </div>

                      <div className="flex items-start">
                        <div className="flex h-6 items-center">
                          <input
                            id="needsBusFromVenue"
                            type="checkbox"
                            {...register("needsBusFromVenue")}
                            className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                          />
                        </div>
                        <div className="ml-3">
                          <label
                            htmlFor="needsBusFromVenue"
                            className="font-medium text-earth-700"
                          >
                            Bus de vuelta
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Dietary Requirements */}
                  <div className="rounded-lg bg-sage-50 p-6">
                    <div className="flex items-start">
                      <div className="flex h-6 items-center">
                        <input
                          id="hasDietaryRestrictions"
                          type="checkbox"
                          {...register("hasDietaryRestrictions")}
                          className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                        />
                      </div>
                      <div className="ml-3">
                        <label
                          htmlFor="hasDietaryRestrictions"
                          className="font-semibold text-earth-700"
                        >
                          Tiene restricciones dietéticas
                        </label>
                      </div>
                    </div>

                    {/* If checked, show restrictions by person */}
                    {hasDietaryRestrictions && (
                      <div className="mt-6 space-y-4">
                        {errors.dietaryRestrictions && (
                          <p className="mt-2 text-sm text-red-600">
                            Debes añadir al menos una restricción por persona
                          </p>
                        )}
                        {dietaryRestrictions.map((restriction, index) => (
                          <div
                            key={index}
                            className="rounded-lg border-2 border-sage-200 bg-white p-4"
                          >
                            {/* Person name with checkbox */}
                            <div className="mb-3 flex items-center">
                              <div className="flex h-6 items-center">
                                <input
                                  id={`dietaryRestrictions.${index}.hasRestriction`}
                                  type="checkbox"
                                  {...register(`dietaryRestrictions.${index}.hasRestriction`)}
                                  className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                                />
                              </div>
                              <div className="ml-3 flex items-center">
                                <label
                                  htmlFor={`dietaryRestrictions.${index}.hasRestriction`}
                                  className="cursor-pointer text-base font-semibold text-earth-800"
                                >
                                  {restriction.personName}
                                </label>
                              </div>
                            </div>

                            {/* Show text areas only if checkbox is checked */}
                            {watch(`dietaryRestrictions.${index}.hasRestriction`) && (
                              <div className="space-y-3">
                                {/* Allergies */}
                                <div>
                                  <label
                                    htmlFor={`dietaryRestrictions.${index}.allergies`}
                                    className="mb-2 block text-sm font-semibold text-earth-700"
                                  >
                                    Alergias e intolerancias:
                                  </label>
                                  <textarea
                                    id={`dietaryRestrictions.${index}.allergies`}
                                    {...register(`dietaryRestrictions.${index}.allergies`)}
                                    rows={1}
                                    className="w-full rounded-lg border-sand-300 px-4 py-2 focus:border-sage-500 focus:ring-sage-500"
                                    placeholder="Ej.: frutos secos, lactosa..."
                                  />
                                </div>

                                {/* Other Restrictions */}
                                <div>
                                  <label
                                    htmlFor={`dietaryRestrictions.${index}.otherRestrictions`}
                                    className="mb-2 block text-sm font-semibold text-earth-700"
                                  >
                                    Otras restricciones dietéticas:
                                  </label>
                                  <textarea
                                    id={`dietaryRestrictions.${index}.otherRestrictions`}
                                    {...register(
                                      `dietaryRestrictions.${index}.otherRestrictions`
                                    )}
                                    rows={1}
                                    className="w-full rounded-lg border-sand-300 px-4 py-2 focus:border-sage-500 focus:ring-sage-500"
                                    placeholder="Ej.: vegano/a, vegetariano/a, celíaco/a..."
                                  />
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                    {errors.hasDietaryRestrictions && (
                      <p className="mt-3 text-sm text-red-600">
                        {errors.hasDietaryRestrictions.message}
                      </p>
                    )}
                  </div>
                </>
              )}

              {/* Submit Button */}
              <div className="flex gap-4 pt-6">
                <Link
                  to="/admin/rsvps"
                  className="flex flex-1 items-center justify-center space-x-2 rounded-lg border-2 border-sand-300 bg-white px-6 py-4 text-lg font-semibold text-earth-700 transition-all hover:bg-sand-50"
                >
                  Cancelar
                </Link>
                <button
                  type="submit"
                  disabled={updateRsvpMutation.isPending}
                  className="flex flex-1 items-center justify-center space-x-2 rounded-lg bg-sage-600 px-6 py-4 text-lg font-semibold text-white shadow-lg transition-all hover:bg-sage-700 hover:shadow-xl disabled:cursor-not-allowed disabled:bg-earth-400"
                >
                  {updateRsvpMutation.isPending ? (
                    <>
                      <div className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      <span>Guardando...</span>
                    </>
                  ) : (
                    <>
                      <Save className="h-5 w-5" />
                      <span>Guardar Cambios</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
