import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTRPC } from "~/trpc/react";
import { useState } from "react";
import { Upload, Image, Mail, CheckCircle, XCircle, Trash2, Users } from "lucide-react";
import toast from "react-hot-toast";

export const Route = createFileRoute("/admin/")({
  component: AdminPage,
});

interface ImageUploadSectionProps {
  title: string;
  description: string;
  imageType: "hero" | "venue1" | "venue2";
  currentImageUrl: string | null | undefined;
}

function ImageUploadSection({
  title,
  description,
  imageType,
  currentImageUrl,
}: ImageUploadSectionProps) {
  const trpc = useTRPC();
  const queryClient = useQueryClient();
  const [isUploading, setIsUploading] = useState(false);
  
  const getUploadUrlMutation = useMutation(
    trpc.getImageUploadUrl.mutationOptions()
  );
  
  const updateSettingsMutation = useMutation(
    trpc.updateSiteSettings.mutationOptions()
  );
  
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Validate file type
    if (!file.type.startsWith("image/")) {
      toast.error("Por favor selecciona un archivo de imagen");
      return;
    }
    
    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error("La imagen es demasiado grande. Máximo 10MB");
      return;
    }
    
    setIsUploading(true);
    const uploadToast = toast.loading("Preparando subida...");
    
    try {
      // Get file extension
      const fileExtension = file.name.split(".").pop() || "jpg";
      
      console.log("=== Starting image upload ===");
      console.log("File name:", file.name);
      console.log("File size:", file.size, "bytes");
      console.log("File type:", file.type);
      console.log("Image type:", imageType);
      console.log("Current page URL:", window.location.href);
      
      // Get presigned upload URL
      console.log("Requesting upload URL...");
      toast.loading("Obteniendo URL de subida...", { id: uploadToast });
      
      let uploadUrl: string;
      let objectName: string;
      
      try {
        const result = await getUploadUrlMutation.mutateAsync({
          imageType,
          fileExtension,
        });
        uploadUrl = result.uploadUrl;
        objectName = result.objectName;
      } catch (trpcError) {
        console.error("❌ Error getting upload URL from tRPC:", trpcError);
        console.error("Error type:", typeof trpcError);
        console.error("Error details:", trpcError);
        
        throw new Error(
          "Error al obtener la URL de subida del servidor.\n\n" +
          "Posibles causas:\n" +
          "• El servidor no está respondiendo\n" +
          "• MinIO no está configurado correctamente\n" +
          "• Problema de conexión con la base de datos\n\n" +
          "Detalles técnicos:\n" +
          (trpcError instanceof Error ? trpcError.message : String(trpcError)) + "\n\n" +
          "Por favor, verifica los logs del servidor."
        );
      }
      
      console.log("Upload URL received:", uploadUrl);
      console.log("Object name:", objectName);
      console.log("URL length:", uploadUrl.length);
      
      // Verify URL is valid
      let uploadUrlParsed: URL;
      try {
        uploadUrlParsed = new URL(uploadUrl);
        console.log("URL validation passed");
        console.log("URL protocol:", uploadUrlParsed.protocol);
        console.log("URL host:", uploadUrlParsed.host);
        console.log("URL hostname:", uploadUrlParsed.hostname);
        console.log("URL port:", uploadUrlParsed.port);
        console.log("URL pathname:", uploadUrlParsed.pathname);
        console.log("URL search params:", uploadUrlParsed.search);
        
        // Check if URL is accessible
        const currentUrl = new URL(window.location.href);
        console.log("Current page protocol:", currentUrl.protocol);
        console.log("Current page host:", currentUrl.host);
        
        // Verify protocol matches
        if (uploadUrlParsed.protocol !== currentUrl.protocol) {
          console.error("❌ PROTOCOL MISMATCH");
          console.error("  Current page uses:", currentUrl.protocol);
          console.error("  Upload URL uses:", uploadUrlParsed.protocol);
          console.error("  This will cause a Mixed Content error!");
          
          throw new Error(
            "Error de configuración: Protocolo no coincide.\n\n" +
            `La página usa ${currentUrl.protocol} pero la URL de subida usa ${uploadUrlParsed.protocol}\n\n` +
            "Esto causará que el navegador bloquee la petición.\n\n" +
            "Solución:\n" +
            "• Asegúrate de acceder a la página con http:// (sin 's')\n" +
            "• O configura el servidor para usar HTTPS correctamente"
          );
        }
        
        // Verify host is accessible
        if (uploadUrlParsed.hostname !== currentUrl.hostname) {
          console.warn("⚠️ WARNING: Upload URL uses different hostname");
          console.warn("  Current page:", currentUrl.hostname);
          console.warn("  Upload URL:", uploadUrlParsed.hostname);
          console.warn("  This might cause CORS or connection issues");
        }
        
        if (uploadUrlParsed.hostname === "localhost" && uploadUrlParsed.port !== currentUrl.port) {
          console.warn("⚠️ WARNING: Upload URL uses localhost with a different port");
          console.warn("  Current page:", window.location.href);
          console.warn("  Upload URL:", uploadUrl);
          console.warn("  This might cause CORS or connection issues");
        }
        
        // Check if the URL is using an internal Docker hostname
        if (uploadUrlParsed.hostname === "minio" || uploadUrlParsed.hostname.includes("docker")) {
          console.error("❌ INTERNAL HOSTNAME DETECTED");
          console.error("  Upload URL uses internal hostname:", uploadUrlParsed.hostname);
          console.error("  This URL is not accessible from the browser!");
          
          throw new Error(
            "Error de configuración: URL interna detectada.\n\n" +
            `La URL de subida usa el hostname interno "${uploadUrlParsed.hostname}" ` +
            "que no es accesible desde el navegador.\n\n" +
            "Esto indica un problema en el código del servidor.\n\n" +
            "Por favor, contacta al administrador del sistema."
          );
        }
      } catch (urlError) {
        if (urlError instanceof Error && urlError.message.includes("Error de configuración")) {
          throw urlError; // Re-throw our custom errors
        }
        console.error("❌ Invalid URL received:", urlError);
        throw new Error("Received invalid upload URL from server");
      }
      
      // Upload file to MinIO with timeout
      console.log("Starting PUT request...");
      console.log("Request method: PUT");
      console.log("Request body size:", file.size);
      console.log("Request Content-Type:", file.type);
      toast.loading("Subiendo imagen...", { id: uploadToast });
      
      // Create an AbortController for timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => {
        console.error("❌ Upload timeout after 60 seconds");
        controller.abort();
      }, 60000); // 60 second timeout
      
      let uploadResponse: Response;
      try {
        console.log("Attempting fetch to:", uploadUrl);
        uploadResponse = await fetch(uploadUrl, {
          method: "PUT",
          body: file,
          headers: {
            "Content-Type": file.type,
          },
          mode: "cors",
          signal: controller.signal,
        });
        
        clearTimeout(timeoutId);
        
        console.log("✅ Upload response received");
        console.log("Status:", uploadResponse.status);
        console.log("Status text:", uploadResponse.statusText);
        console.log("Headers:", Object.fromEntries(uploadResponse.headers.entries()));
      } catch (fetchError) {
        clearTimeout(timeoutId);
        console.error("❌ Fetch error:", fetchError);
        console.error("Error type:", typeof fetchError);
        console.error("Error name:", fetchError instanceof Error ? fetchError.name : "Unknown");
        console.error("Error message:", fetchError instanceof Error ? fetchError.message : String(fetchError));
        
        // Provide more specific error messages
        if (fetchError instanceof Error) {
          if (fetchError.name === "AbortError") {
            throw new Error(
              "La subida tardó demasiado tiempo (más de 60 segundos).\n\n" +
              "Posibles soluciones:\n" +
              "• Intenta con una imagen más pequeña\n" +
              "• Verifica tu conexión a internet\n" +
              "• Recarga la página e intenta de nuevo"
            );
          } else if (fetchError.message.includes("Failed to fetch") || fetchError.message.includes("NetworkError") || fetchError.message.includes("network error")) {
            // Get more diagnostic info
            const currentUrl = new URL(window.location.href);
            const isLocalhost = uploadUrlParsed.hostname === "localhost" || uploadUrlParsed.hostname === "127.0.0.1";
            const sameHost = uploadUrlParsed.host === currentUrl.host;
            
            let diagnosticInfo = "Información de diagnóstico:\n";
            diagnosticInfo += `• Página actual: ${currentUrl.href}\n`;
            diagnosticInfo += `• URL de subida: ${uploadUrlParsed.protocol}//${uploadUrlParsed.host}${uploadUrlParsed.pathname}\n`;
            diagnosticInfo += `• Protocolo: ${uploadUrlParsed.protocol}\n`;
            diagnosticInfo += `• Host: ${uploadUrlParsed.host}\n`;
            diagnosticInfo += `• Es localhost: ${isLocalhost ? "Sí" : "No"}\n`;
            diagnosticInfo += `• Mismo host que la página: ${sameHost ? "Sí" : "No"}\n`;
            
            throw new Error(
              "Error de red al intentar subir la imagen.\n\n" +
              "El navegador no pudo conectarse al servidor.\n\n" +
              "Posibles causas y soluciones:\n\n" +
              "1. Docker/Nginx no está funcionando:\n" +
              "   • Ejecuta: ./scripts/stop && ./scripts/run\n" +
              "   • Verifica: docker ps\n\n" +
              "2. Extensión del navegador bloqueando la petición:\n" +
              "   • Prueba en modo incógnito (Ctrl+Shift+N)\n" +
              "   • Desactiva bloqueadores de anuncios\n\n" +
              "3. Firewall o antivirus bloqueando la conexión:\n" +
              "   • Desactiva temporalmente el firewall\n" +
              "   • Añade localhost:8000 a la lista blanca\n\n" +
              "4. Configuración de Nginx incorrecta:\n" +
              "   • Verifica que proxy_set_header Host minio:9000;\n" +
              "   • Consulta: SOLUCION_NETWORK_ERROR.md\n\n" +
              diagnosticInfo + "\n\n" +
              "Para más ayuda, consulta SOLUCION_NETWORK_ERROR.md\n" +
              "o revisa la consola del navegador (F12) para más detalles."
            );
          } else if (fetchError.message.includes("CORS")) {
            throw new Error(
              "Error de CORS (Cross-Origin Resource Sharing).\n\n" +
              "Esto indica un problema de configuración del servidor.\n" +
              "Por favor, contacta al administrador del sistema.\n\n" +
              "Detalles: " + fetchError.message
            );
          }
        }
        
        throw fetchError;
      }
      
      if (!uploadResponse.ok) {
        const errorText = await uploadResponse.text().catch(() => "Unknown error");
        console.error("❌ Upload failed with status:", uploadResponse.status);
        console.error("Error response:", errorText);
        throw new Error(
          `Error al subir la imagen (código ${uploadResponse.status}).\n\n` +
          (errorText ? `Detalles: ${errorText}` : "No hay detalles adicionales disponibles.")
        );
      }
      
      console.log("✅ Upload successful, updating database...");
      toast.loading("Guardando cambios...", { id: uploadToast });
      
      // Update database with new image URL
      await updateSettingsMutation.mutateAsync({
        imageType,
        objectName,
      });
      
      console.log("✅ Database updated successfully");
      
      // Invalidate queries to refresh the UI
      await queryClient.invalidateQueries({
        queryKey: trpc.getSiteSettings.queryKey(),
      });
      
      toast.success("¡Imagen actualizada correctamente!", { id: uploadToast });
      console.log("=== Upload complete ===");
    } catch (error) {
      console.error("=== Upload failed ===");
      console.error("Error:", error);
      console.error("Error type:", typeof error);
      console.error("Error name:", error instanceof Error ? error.name : "Unknown");
      console.error("Error message:", error instanceof Error ? error.message : String(error));
      console.error("Error stack:", error instanceof Error ? error.stack : "No stack trace");
      
      let errorMessage = "Error desconocido al actualizar la imagen";
      
      if (error instanceof Error) {
        errorMessage = error.message;
      }
      
      toast.error(errorMessage, { id: uploadToast, duration: 10000 });
    } finally {
      setIsUploading(false);
      // Reset the input
      e.target.value = "";
    }
  };
  
  return (
    <div className="rounded-lg border border-sage-200 bg-white p-6 shadow-sm">
      <div className="mb-4">
        <h3 className="text-xl font-semibold text-earth-800">{title}</h3>
        <p className="text-sm text-earth-600">{description}</p>
      </div>
      
      {/* Current Image Preview */}
      <div className="mb-4">
        {currentImageUrl ? (
          <div
            className="h-48 w-full rounded-lg bg-cover bg-center"
            style={{ backgroundImage: `url('${currentImageUrl}')` }}
          />
        ) : (
          <div className="flex h-48 w-full items-center justify-center rounded-lg bg-sand-100">
            <Image className="h-12 w-12 text-sand-400" />
          </div>
        )}
      </div>
      
      {/* Upload Button */}
      <label className="flex cursor-pointer items-center justify-center gap-2 rounded-lg bg-sage-600 px-4 py-3 text-white transition-colors hover:bg-sage-700 disabled:cursor-not-allowed disabled:opacity-50">
        <Upload className="h-5 w-5" />
        <span>{isUploading ? "Subiendo..." : "Cambiar Imagen"}</span>
        <input
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          disabled={isUploading}
          className="hidden"
        />
      </label>
    </div>
  );
}

function EmailTestSection() {
  const trpc = useTRPC();
  const [testEmail, setTestEmail] = useState("");
  const [testResult, setTestResult] = useState<{
    success: boolean;
    message: string;
    error?: string;
    errorDetails?: string;
    details?: any;
  } | null>(null);
  
  const testEmailMutation = useMutation(
    trpc.testEmail.mutationOptions()
  );
  
  const handleTestEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!testEmail) {
      toast.error("Por favor, introduce un email");
      return;
    }
    
    const testToast = toast.loading("Enviando email de prueba...");
    setTestResult(null);
    
    try {
      const result = await testEmailMutation.mutateAsync({
        testEmailAddress: testEmail,
      });
      
      setTestResult(result);
      
      if (result.success) {
        toast.success("¡Email de prueba enviado! Revisa tu bandeja de entrada.", { 
          id: testToast,
          duration: 5000,
        });
      } else {
        toast.error("Error al enviar email de prueba. Ver detalles abajo.", { 
          id: testToast,
          duration: 5000,
        });
      }
    } catch (error) {
      console.error("Error testing email:", error);
      toast.error("Error al probar el email", { id: testToast });
      setTestResult({
        success: false,
        message: "Error al enviar email de prueba",
        error: error instanceof Error ? error.message : String(error),
      });
    }
  };
  
  return (
    <div className="rounded-lg border border-sage-200 bg-white p-6 shadow-sm">
      <div className="mb-4">
        <h3 className="text-xl font-semibold text-earth-800">
          Probar Configuración de Email
        </h3>
        <p className="text-sm text-earth-600">
          Envía un email de prueba para verificar que la configuración SMTP está funcionando correctamente
        </p>
      </div>
      
      <form onSubmit={handleTestEmail} className="space-y-4">
        <div>
          <label htmlFor="testEmail" className="block text-sm font-medium text-earth-700">
            Email de prueba
          </label>
          <input
            type="email"
            id="testEmail"
            value={testEmail}
            onChange={(e) => setTestEmail(e.target.value)}
            placeholder="tu@email.com"
            className="mt-1 block w-full rounded-md border-sage-300 shadow-sm focus:border-sage-500 focus:ring-sage-500"
          />
        </div>
        
        <button
          type="submit"
          disabled={testEmailMutation.isPending}
          className="flex items-center justify-center gap-2 rounded-lg bg-sage-600 px-4 py-3 text-white transition-colors hover:bg-sage-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Mail className="h-5 w-5" />
          <span>
            {testEmailMutation.isPending ? "Enviando..." : "Enviar Email de Prueba"}
          </span>
        </button>
      </form>
      
      {/* Test Result Display */}
      {testResult && (
        <div className={`mt-6 rounded-lg border p-4 ${
          testResult.success 
            ? "border-green-200 bg-green-50" 
            : "border-red-200 bg-red-50"
        }`}>
          <div className="flex items-start gap-3">
            {testResult.success ? (
              <CheckCircle className="h-6 w-6 flex-shrink-0 text-green-600" />
            ) : (
              <XCircle className="h-6 w-6 flex-shrink-0 text-red-600" />
            )}
            <div className="flex-1">
              <h4 className={`font-semibold ${
                testResult.success ? "text-green-900" : "text-red-900"
              }`}>
                {testResult.message}
              </h4>
              
              {testResult.error && (
                <div className="mt-2">
                  <p className="text-sm font-medium text-red-800">Error:</p>
                  <p className="mt-1 text-sm text-red-700">{testResult.error}</p>
                </div>
              )}
              
              {testResult.errorDetails && (
                <div className="mt-3 rounded bg-red-100 p-3">
                  <p className="whitespace-pre-line text-sm text-red-900">
                    {testResult.errorDetails}
                  </p>
                </div>
              )}
              
              {testResult.details && (
                <div className="mt-3">
                  <p className="text-sm font-medium text-earth-800">Detalles de configuración:</p>
                  <dl className="mt-2 space-y-1 text-sm text-earth-700">
                    {Object.entries(testResult.details).map(([key, value]) => (
                      <div key={key}>
                        <dt className="inline font-medium">{key}:</dt>{" "}
                        <dd className="inline">{String(value)}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function ResetDataSection() {
  const trpc = useTRPC();
  const queryClient = useQueryClient();
  const [showConfirmation, setShowConfirmation] = useState(false);
  
  const resetDataMutation = useMutation(
    trpc.resetRsvpData.mutationOptions()
  );
  
  const handleReset = async () => {
    const resetToast = toast.loading("Eliminando datos de RSVP...");
    
    try {
      const result = await resetDataMutation.mutateAsync();
      
      // Invalidate any queries that might be affected
      await queryClient.invalidateQueries();
      
      toast.success(result.message, { 
        id: resetToast,
        duration: 5000,
      });
      
      setShowConfirmation(false);
    } catch (error) {
      console.error("Error resetting RSVP data:", error);
      toast.error("Error al eliminar los datos", { id: resetToast });
    }
  };
  
  return (
    <div className="rounded-lg border border-red-200 bg-white p-6 shadow-sm">
      <div className="mb-4">
        <h3 className="text-xl font-semibold text-earth-800">
          Resetear Datos de RSVP
        </h3>
        <p className="text-sm text-earth-600">
          Elimina todos los registros de confirmaciones. Esta acción no se puede deshacer.
        </p>
      </div>
      
      {!showConfirmation ? (
        <button
          onClick={() => setShowConfirmation(true)}
          className="flex items-center justify-center gap-2 rounded-lg bg-red-600 px-4 py-3 text-white transition-colors hover:bg-red-700"
        >
          <Trash2 className="h-5 w-5" />
          <span>Resetear Datos</span>
        </button>
      ) : (
        <div className="space-y-4">
          <div className="rounded-lg bg-red-50 p-4">
            <p className="font-semibold text-red-900">
              ¿Estás seguro/a de que quieres eliminar todos los datos de RSVP?
            </p>
            <p className="mt-2 text-sm text-red-800">
              Esta acción eliminará todas las confirmaciones y no se puede deshacer.
            </p>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={handleReset}
              disabled={resetDataMutation.isPending}
              className="flex-1 rounded-lg bg-red-600 px-4 py-3 font-semibold text-white transition-colors hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {resetDataMutation.isPending ? "Eliminando..." : "Sí, eliminar todo"}
            </button>
            <button
              onClick={() => setShowConfirmation(false)}
              disabled={resetDataMutation.isPending}
              className="flex-1 rounded-lg bg-sand-200 px-4 py-3 font-semibold text-earth-800 transition-colors hover:bg-sand-300 disabled:cursor-not-allowed disabled:opacity-50"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function AdminPage() {
  const trpc = useTRPC();
  const settingsQuery = useQuery(trpc.getSiteSettings.queryOptions());
  
  if (settingsQuery.isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-lg text-earth-600">Cargando...</div>
      </div>
    );
  }
  
  if (settingsQuery.isError) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-lg text-red-600">Error al cargar la configuración</div>
      </div>
    );
  }
  
  const settings = settingsQuery.data;
  
  return (
    <div className="min-h-screen bg-sand-50 px-4 py-12 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-5xl">
        {/* Header */}
        <div className="mb-12 text-center">
          <h1 className="mb-4 font-serif text-4xl font-light tracking-wide text-earth-800 sm:text-5xl">
            Administración de Imágenes
          </h1>
          <div className="mx-auto h-px w-24 bg-sage-400" />
          <p className="mt-4 text-earth-600">
            Cambia las imágenes de tu sitio web de boda
          </p>
        </div>
        
        {/* RSVP Management Section */}
        <div className="mb-8 rounded-lg border border-sage-200 bg-white p-6 shadow-sm">
          <div className="mb-4">
            <h3 className="text-xl font-semibold text-earth-800">Gestión de RSVPs</h3>
            <p className="text-sm text-earth-600">
              Ver y editar las respuestas de confirmación de los invitados
            </p>
          </div>
          
          <a
            href="/admin/rsvps"
            className="flex items-center justify-center gap-2 rounded-lg bg-sage-600 px-4 py-3 text-white transition-colors hover:bg-sage-700"
          >
            <Users className="h-5 w-5" />
            <span>Ver RSVPs</span>
          </a>
        </div>
        
        {/* Upload Sections */}
        <div className="space-y-8">
          {/* Email Test Section */}
          <EmailTestSection />
          
          {/* Reset Data Section */}
          <ResetDataSection />
          
          <ImageUploadSection
            title="Imagen Principal (Hero)"
            description="Esta es la imagen de fondo principal que se muestra en la parte superior de la página"
            imageType="hero"
            currentImageUrl={settings?.heroImageUrl}
          />
          
          <ImageUploadSection
            title="Imagen del Lugar 1"
            description="Primera imagen de la sección de detalles del lugar"
            imageType="venue1"
            currentImageUrl={settings?.venueImage1Url}
          />
          
          <ImageUploadSection
            title="Imagen del Lugar 2"
            description="Segunda imagen de la sección de detalles del lugar"
            imageType="venue2"
            currentImageUrl={settings?.venueImage2Url}
          />
        </div>
        
        {/* Back to Home Link */}
        <div className="mt-12 text-center">
          <a
            href="/"
            className="inline-block text-sage-700 underline hover:text-sage-800"
          >
            ← Volver a la página principal
          </a>
        </div>
      </div>
    </div>
  );
}
