import React from "react";
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { useTRPC } from "~/trpc/react";
import toast from "react-hot-toast";
import { ArrowLeft, Plus, X, Send, CheckCircle, XCircle } from "lucide-react";
import { ScrollToTopButton } from "~/components/ScrollToTopButton";
import { WeddingFooter } from "~/components/WeddingFooter";

export const Route = createFileRoute("/rsvp/")({
  component: RsvpPage,
});

const rsvpSchema = z
  .object({
    email: z.string().email("Por favor, introduce un email válido"),
    status: z.enum(["accepted", "declined"], {
      errorMap: () => ({ message: "Debes seleccionar una opción" }),
    }),
    fullName: z
      .string()
      .min(1, "El nombre completo es obligatorio")
      .refine(
        (value) => {
          const words = value.trim().split(/\s+/).filter(word => word.length > 0);
          return words.length >= 2;
        },
        {
          message: "Por favor, introduce tu nombre y al menos un apellido",
        }
      ),
    // Fields only for accepted invitations
    isAccompanied: z.boolean().optional(),
    accompaniedAdultName: z.string().optional(),
    children: z
      .array(
        z.object({
          name: z.string().min(1, "El nombre del niño/a es obligatorio"),
        })
      )
      .max(3, "Máximo 3 niños")
      .optional(),
    needsBusToVenue: z.boolean().optional(),
    needsBusFromVenue: z.boolean().optional(),
    hasDietaryRestrictions: z.boolean().optional(),
    dietaryRestrictions: z
      .array(
        z.object({
          personName: z.string(),
          hasRestriction: z.boolean(),
          allergies: z.string(),
          otherRestrictions: z.string(),
        })
      )
      .optional(),
  })
  .refine(
    (data) => {
      // If accepted and accompanied, must have either adult or children
      if (data.status === "accepted" && data.isAccompanied) {
        const hasAdult = data.accompaniedAdultName && data.accompaniedAdultName.trim() !== "";
        const hasChildren = data.children && data.children.length > 0;
        return hasAdult || hasChildren;
      }
      return true;
    },
    {
      message: "Si vienes acompañado, debes indicar al menos un acompañante adulto o niño/a",
      path: ["isAccompanied"],
    }
  )
  .refine(
    (data) => {
      // If has dietary restrictions, at least one person must have hasRestriction checked
      if (data.status === "accepted" && data.hasDietaryRestrictions) {
        const restrictions = data.dietaryRestrictions || [];
        return restrictions.some(r => r.hasRestriction === true);
      }
      return true;
    },
    {
      message: "Debes marcar al menos una persona con restricciones alimentarias",
      path: ["hasDietaryRestrictions"],
    }
  )
  .refine(
    (data) => {
      // For each person with hasRestriction true, must have at least one field filled
      if (data.status === "accepted" && data.hasDietaryRestrictions) {
        const restrictions = data.dietaryRestrictions || [];
        return restrictions.every(r => {
          if (r.hasRestriction) {
            const hasAllergies = r.allergies && r.allergies.trim() !== "";
            const hasOther = r.otherRestrictions && r.otherRestrictions.trim() !== "";
            return hasAllergies || hasOther;
          }
          return true;
        });
      }
      return true;
    },
    {
      message: "Para cada persona marcada, debes rellenar al menos alergias o restricciones dietéticas",
      path: ["dietaryRestrictions"],
    }
  );

type RsvpFormData = z.infer<typeof rsvpSchema>;

function RsvpPage() {
  const router = useRouter();
  const trpc = useTRPC();
  const submitRsvpMutation = useMutation(trpc.submitRsvp.mutationOptions());

  const {
    register,
    handleSubmit,
    watch,
    control,
    setValue,
    formState: { errors },
  } = useForm<RsvpFormData>({
    resolver: zodResolver(rsvpSchema),
    defaultValues: {
      email: "",
      status: undefined,
      fullName: "",
      isAccompanied: false,
      accompaniedAdultName: "",
      children: [],
      needsBusToVenue: false,
      needsBusFromVenue: false,
      hasDietaryRestrictions: false,
      dietaryRestrictions: [],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "children",
  });

  const status = watch("status");
  const isAccompanied = watch("isAccompanied");
  const hasDietaryRestrictions = watch("hasDietaryRestrictions");
  const fullName = watch("fullName");
  const accompaniedAdultName = watch("accompaniedAdultName");
  const children = watch("children");
  const dietaryRestrictions = watch("dietaryRestrictions") || [];

  // Helper function to get all person names
  const getAllPersonNames = (): string[] => {
    const names: string[] = [];
    if (fullName && fullName.trim()) {
      names.push(fullName.trim());
    }
    if (isAccompanied && accompaniedAdultName && accompaniedAdultName.trim()) {
      names.push(accompaniedAdultName.trim());
    }
    if (isAccompanied && children && children.length > 0) {
      children.forEach((child) => {
        if (child.name && child.name.trim()) {
          names.push(child.name.trim());
        }
      });
    }
    return names;
  };

  // Update dietary restrictions when person names change
  React.useEffect(() => {
    if (status === "accepted" && hasDietaryRestrictions) {
      const allNames = getAllPersonNames();
      const currentRestrictions = dietaryRestrictions || [];
      
      // Check if the names have changed
      const currentNames = currentRestrictions.map(r => r.personName);
      const namesChanged = 
        allNames.length !== currentNames.length ||
        allNames.some((name, i) => name !== currentNames[i]);
      
      if (namesChanged) {
        // Create a map of existing restrictions
        const restrictionsMap = new Map(
          currentRestrictions.map((r) => [r.personName, r])
        );
        
        // Create new restrictions array matching current names
        const newRestrictions = allNames.map((name) => {
          const existing = restrictionsMap.get(name);
          return existing || {
            personName: name,
            hasRestriction: false,
            allergies: "",
            otherRestrictions: "",
          };
        });
        
        setValue("dietaryRestrictions", newRestrictions);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, hasDietaryRestrictions, fullName, accompaniedAdultName, children, setValue]);

  const onSubmit = async (data: RsvpFormData) => {
    const submitPromise = submitRsvpMutation.mutateAsync({
      email: data.email,
      status: data.status,
      fullName: data.fullName,
      isAccompanied: data.status === "accepted" ? data.isAccompanied : undefined,
      accompaniedAdultName:
        data.status === "accepted" ? data.accompaniedAdultName : undefined,
      childrenNames:
        data.status === "accepted" && data.children
          ? data.children.map((c) => c.name)
          : undefined,
      needsBusToVenue: data.status === "accepted" ? data.needsBusToVenue : undefined,
      needsBusFromVenue: data.status === "accepted" ? data.needsBusFromVenue : undefined,
      hasDietaryRestrictions: data.status === "accepted" ? data.hasDietaryRestrictions : undefined,
      dietaryRestrictions:
        data.status === "accepted" && data.hasDietaryRestrictions
          ? data.dietaryRestrictions
          : undefined,
    });

    const successMessage =
      data.status === "accepted"
        ? "¡Confirmación enviada con éxito! Nos vemos en la boda 💕"
        : "Gracias por tu respuesta. Hemos recibido tu mensaje.";

    await toast.promise(submitPromise, {
      loading: "Enviando respuesta...",
      success: successMessage,
      error: (err) => err.message || "Error al enviar. Por favor, inténtalo de nuevo.",
    });

    // Redirect to home after successful submission
    setTimeout(() => {
      router.navigate({ to: "/" });
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-sand-50">
      {/* Header */}
      <div className="relative overflow-hidden px-4 py-8 text-center text-white">
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('/watercolor-garden-scene.jpg')`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-earth-900/50 via-earth-900/55 to-earth-900/60" />
        </div>

        {/* Content */}
        <div className="relative z-10">
          <Link
            to="/"
            className="mb-4 inline-flex items-center space-x-2 text-sm text-sand-300 transition-colors hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Volver al inicio</span>
          </Link>
          <h1 className="font-serif text-4xl font-light tracking-wide sm:text-5xl">
            Responde a la Invitación
          </h1>
          <p className="mt-2 text-sand-200">
            Adrián & Celia • 12 de septiembre, 2026
          </p>
        </div>
      </div>

      {/* Form Container */}
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="overflow-hidden rounded-2xl bg-white shadow-xl">
          <div className="p-6 sm:p-12">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
              {/* Email */}
              <div>
                <label
                  htmlFor="email"
                  className="mb-2 block text-sm font-semibold text-earth-700"
                >
                  Email: *
                </label>
                <input
                  id="email"
                  type="email"
                  {...register("email")}
                  className="w-full rounded-lg border-sand-300 px-4 py-3 focus:border-sage-500 focus:ring-sage-500"
                  placeholder="tu@email.com"
                />
                {errors.email && (
                  <p className="mt-2 text-sm text-red-600">{errors.email.message}</p>
                )}
                <p className="mt-1 text-xs text-earth-500">
                  Usaremos este email para enviarte la confirmación.
                </p>
              </div>

              {/* Status Selection */}
              <div className="rounded-lg border-2 border-sage-200 bg-sage-50 p-6">
                <label className="mb-4 block text-base font-semibold text-earth-800">
                  ¿Podrás asistir a la boda? *
                </label>
                <div className="space-y-3">
                  <label className="flex cursor-pointer items-start rounded-lg border-2 border-sand-200 bg-white p-4 transition-all hover:border-sage-400 has-[:checked]:border-sage-600 has-[:checked]:bg-sage-50">
                    <input
                      type="radio"
                      value="accepted"
                      {...register("status")}
                      className="mt-1 h-5 w-5 border-sand-300 text-sage-600 focus:ring-sage-500"
                    />
                    <div className="ml-3">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-5 w-5 text-sage-600" />
                        <span className="font-semibold text-earth-800">
                          Sí, asistiré.
                        </span>
                      </div>
                    </div>
                  </label>

                  <label className="flex cursor-pointer items-start rounded-lg border-2 border-sand-200 bg-white p-4 transition-all hover:border-earth-400 has-[:checked]:border-earth-600 has-[:checked]:bg-earth-50">
                    <input
                      type="radio"
                      value="declined"
                      {...register("status")}
                      className="mt-1 h-5 w-5 border-sand-300 text-earth-600 focus:ring-earth-500"
                    />
                    <div className="ml-3">
                      <div className="flex items-center space-x-2">
                        <XCircle className="h-5 w-5 text-earth-600" />
                        <span className="font-semibold text-earth-800">
                          No podré asistir.
                        </span>
                      </div>
                    </div>
                  </label>
                </div>
                {errors.status && (
                  <p className="mt-3 text-sm text-red-600">{errors.status.message}</p>
                )}
              </div>

              {/* Full Name */}
              <div>
                <label
                  htmlFor="fullName"
                  className="mb-2 block text-sm font-semibold text-earth-700"
                >
                  Nombre completo: *
                </label>
                <input
                  id="fullName"
                  type="text"
                  {...register("fullName")}
                  className="w-full rounded-lg border-sand-300 px-4 py-3 focus:border-sage-500 focus:ring-sage-500"
                  placeholder="Tu nombre completo"
                />
                {errors.fullName && (
                  <p className="mt-2 text-sm text-red-600">{errors.fullName.message}</p>
                )}
              </div>

              {/* Only show additional fields if accepted */}
              {status === "accepted" && (
                <>
                  {/* Is Accompanied */}
                  <div className="rounded-lg bg-sage-50 p-6">
                    <div className="flex items-start">
                      <div className="flex h-6 items-center">
                        <input
                          id="isAccompanied"
                          type="checkbox"
                          {...register("isAccompanied")}
                          className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                        />
                      </div>
                      <div className="ml-3">
                        <label
                          htmlFor="isAccompanied"
                          className="font-semibold text-earth-700"
                        >
                          Vendré acompañado/a.
                        </label>
                      </div>
                    </div>

                    {/* Accompanied Guests */}
                    {isAccompanied && (
                      <div className="mt-6 space-y-6">
                        {/* Adult Companion */}
                        <div>
                          <label
                            htmlFor="accompaniedAdultName"
                            className="mb-2 block text-sm font-semibold text-earth-700"
                          >
                            Acompañante adulto:
                          </label>
                          <input
                            id="accompaniedAdultName"
                            type="text"
                            {...register("accompaniedAdultName")}
                            className="w-full rounded-lg border-sand-300 px-4 py-3 focus:border-sage-500 focus:ring-sage-500"
                            placeholder="Nombre completo"
                          />
                        </div>

                        {/* Children */}
                        <div>
                          <div className="mb-3 flex items-center justify-between">
                            <label className="text-sm font-semibold text-earth-700">
                              Niños/as:
                            </label>
                            {fields.length < 3 && (
                              <button
                                type="button"
                                onClick={() => append({ name: "" })}
                                className="flex items-center space-x-1 rounded-lg bg-sage-600 px-3 py-2 text-sm font-semibold text-white transition-colors hover:bg-sage-700"
                              >
                                <Plus className="h-4 w-4" />
                                <span>Añadir niño/a</span>
                              </button>
                            )}
                          </div>

                          {fields.length === 0 && (
                            <p className="text-sm italic text-earth-500">
                              Haz clic en "Añadir niño/a" si vienes con niños
                            </p>
                          )}

                          <div className="space-y-3">
                            {fields.map((field, index) => (
                              <div key={field.id} className="flex items-start space-x-3">
                                <div className="flex-1">
                                  <input
                                    type="text"
                                    {...register(`children.${index}.name`)}
                                    className="w-full rounded-lg border-sand-300 px-4 py-3 focus:border-sage-500 focus:ring-sage-500"
                                    placeholder={`Nombre del niño/a ${index + 1}`}
                                  />
                                  {errors.children?.[index]?.name && (
                                    <p className="mt-1 text-sm text-red-600">
                                      {errors.children[index]?.name?.message}
                                    </p>
                                  )}
                                </div>
                                <button
                                  type="button"
                                  onClick={() => remove(index)}
                                  className="mt-3 rounded-lg bg-red-100 p-2 text-red-600 transition-colors hover:bg-red-200"
                                >
                                  <X className="h-5 w-5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    )}
                    {errors.isAccompanied && (
                      <p className="mt-3 text-sm text-red-600">
                        {errors.isAccompanied.message}
                      </p>
                    )}
                  </div>

                  {/* Bus Service */}
                  <div className="rounded-lg border-2 border-sage-200 p-6">
                    <h3 className="mb-4 text-lg font-semibold text-earth-800">
                      Servicio de autobús desde Madrid:
                    </h3>

                    <div className="space-y-3">
                      <div className="flex items-start">
                        <div className="flex h-6 items-center">
                          <input
                            id="needsBusToVenue"
                            type="checkbox"
                            {...register("needsBusToVenue")}
                            className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                          />
                        </div>
                        <div className="ml-3">
                          <label
                            htmlFor="needsBusToVenue"
                            className="font-medium text-earth-700"
                          >
                            Quiero bus de ida (Nuevos Ministerios 12/09 15:00h → Finca).
                          </label>
                        </div>
                      </div>

                      <div className="flex items-start">
                        <div className="flex h-6 items-center">
                          <input
                            id="needsBusFromVenue"
                            type="checkbox"
                            {...register("needsBusFromVenue")}
                            className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                          />
                        </div>
                        <div className="ml-3">
                          <label
                            htmlFor="needsBusFromVenue"
                            className="font-medium text-earth-700"
                          >
                            Quiero bus de vuelta (Finca 13/09 01:00h → Nuevos Ministerios).
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Dietary Requirements */}
                  <div className="rounded-lg bg-sage-50 p-6">
                    <div className="flex items-start">
                      <div className="flex h-6 items-center">
                        <input
                          id="hasDietaryRestrictions"
                          type="checkbox"
                          {...register("hasDietaryRestrictions")}
                          className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                        />
                      </div>
                      <div className="ml-3">
                        <label
                          htmlFor="hasDietaryRestrictions"
                          className="font-semibold text-earth-700"
                        >
                          {isAccompanied 
                            ? "Tenemos restricciones alimentarias."
                            : "Tengo restricciones alimentarias."}
                        </label>
                      </div>
                    </div>

                    {/* If checked, show restrictions by person */}
                    {hasDietaryRestrictions && (
                      <div className="mt-6 space-y-4">
                        {errors.dietaryRestrictions && (
                          <p className="mt-2 text-sm text-red-600">
                            Debes añadir al menos una restricción por persona
                          </p>
                        )}
                        {dietaryRestrictions.map((restriction, index) => (
                          <div
                            key={index}
                            className="rounded-lg border-2 border-sage-200 bg-white p-4"
                          >
                            {/* Person name with checkbox */}
                            <div className="mb-3 flex items-center">
                              <div className="flex h-6 items-center">
                                <input
                                  id={`dietaryRestrictions.${index}.hasRestriction`}
                                  type="checkbox"
                                  {...register(`dietaryRestrictions.${index}.hasRestriction`)}
                                  className="h-5 w-5 rounded border-sand-300 text-sage-600 focus:ring-sage-500"
                                />
                              </div>
                              <div className="ml-3 flex items-center">
                                <label
                                  htmlFor={`dietaryRestrictions.${index}.hasRestriction`}
                                  className="cursor-pointer text-base font-semibold text-earth-800"
                                >
                                  {restriction.personName}
                                </label>
                              </div>
                            </div>

                            {/* Show text areas only if checkbox is checked */}
                            {watch(`dietaryRestrictions.${index}.hasRestriction`) && (
                              <div className="space-y-3">
                                {/* Allergies */}
                                <div>
                                  <label
                                    htmlFor={`dietaryRestrictions.${index}.allergies`}
                                    className="mb-2 block text-sm font-semibold text-earth-700"
                                  >
                                    Alergias e intolerancias:
                                  </label>
                                  <textarea
                                    id={`dietaryRestrictions.${index}.allergies`}
                                    {...register(`dietaryRestrictions.${index}.allergies`)}
                                    rows={1}
                                    className="w-full rounded-lg border-sand-300 px-4 py-2 focus:border-sage-500 focus:ring-sage-500"
                                    placeholder="Ej.: frutos secos, lactosa..."
                                  />
                                </div>

                                {/* Other Restrictions */}
                                <div>
                                  <label
                                    htmlFor={`dietaryRestrictions.${index}.otherRestrictions`}
                                    className="mb-2 block text-sm font-semibold text-earth-700"
                                  >
                                    Otras restricciones dietéticas:
                                  </label>
                                  <textarea
                                    id={`dietaryRestrictions.${index}.otherRestrictions`}
                                    {...register(
                                      `dietaryRestrictions.${index}.otherRestrictions`
                                    )}
                                    rows={1}
                                    className="w-full rounded-lg border-sand-300 px-4 py-2 focus:border-sage-500 focus:ring-sage-500"
                                    placeholder="Ej.: vegano/a, vegetariano/a, celíaco/a..."
                                  />
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                    {errors.hasDietaryRestrictions && (
                      <p className="mt-3 text-sm text-red-600">
                        {errors.hasDietaryRestrictions.message}
                      </p>
                    )}
                  </div>
                </>
              )}

              {/* Submit Button */}
              <div className="pt-6">
                <button
                  type="submit"
                  disabled={submitRsvpMutation.isPending}
                  className="flex w-full items-center justify-center space-x-2 rounded-lg bg-sage-600 px-6 py-4 text-lg font-semibold text-white shadow-lg transition-all hover:bg-sage-700 hover:shadow-xl disabled:cursor-not-allowed disabled:bg-earth-400"
                >
                  {submitRsvpMutation.isPending ? (
                    <>
                      <div className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent" />
                      <span>Enviando...</span>
                    </>
                  ) : (
                    <>
                      <Send className="h-5 w-5" />
                      <span>Enviar Respuesta</span>
                    </>
                  )}
                </button>
              </div>

              {/* Footer Note */}
              <p className="text-center text-sm text-earth-500">
                Por favor, responde antes del
                <span className="sm:hidden"><br /></span>{" "}
                <span className="font-semibold text-earth-700">1 de julio de 2026</span>.
              </p>
            </form>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-8 rounded-xl bg-sage-50 p-6 text-center">
          <p className="text-sm leading-relaxed text-earth-700">
            ¡Estamos deseando celebrar este día tan especial contigo!
          </p>
          <p className="mt-4 text-sm leading-relaxed text-earth-700">
            Si tienes alguna pregunta o necesitas ayuda con el formulario, no dudes en
            contactarnos:
          </p>
          <p className="mt-2 text-base font-semibold text-sage-700">
            bodaadrianycelia@gmail.com
          </p>
        </div>

        {/* Scroll to Top Button */}
        <ScrollToTopButton />
      </div>

      {/* Footer */}
      <WeddingFooter />
    </div>
  );
}
