/** @type {import('tailwindcss').Config} */
export default {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./index.html"],
  theme: {
    extend: {
      colors: {
        sage: {
          50: "#f4f7f5",
          100: "#e3ebe6",
          200: "#c7d7cd",
          300: "#a3bfae",
          400: "#7da38b",
          500: "#5f8a70",
          600: "#4a6f5a",
          700: "#3d5a4a",
          800: "#334b3d",
          900: "#2b3f34",
        },
        sand: {
          50: "#faf8f5",
          100: "#f4f0e8",
          200: "#e8dfd0",
          300: "#d9c9b0",
          400: "#c8ae8d",
          500: "#b89670",
          600: "#a67f5e",
          700: "#8a6a4f",
          800: "#725744",
          900: "#5e493a",
        },
        earth: {
          50: "#f6f4f2",
          100: "#ebe6e1",
          200: "#d8cdc3",
          300: "#c0ad9d",
          400: "#a78c78",
          500: "#93755f",
          600: "#866253",
          700: "#705146",
          800: "#5d443c",
          900: "#4d3933",
        },
      },
      fontFamily: {
        serif: ["Fraunces", "Georgia", "serif"],
        sans: ["Montserrat", "system-ui", "sans-serif"],
        allura: ["Allura", "cursive"],
      },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};
