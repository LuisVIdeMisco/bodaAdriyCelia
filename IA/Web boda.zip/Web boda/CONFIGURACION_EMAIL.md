# Configuración de Email para el Sistema de Boda

Este documento explica cómo configurar correctamente el envío de emails usando Gmail.

## 🚨 Problema Actual

Los emails no se están enviando debido a un error de autenticación SMTP. Esto significa que la contraseña configurada no es válida o ha sido revocada.

## ✅ Solución: Configurar Gmail App Password

Gmail requiere una "Contraseña de Aplicación" especial para permitir que aplicaciones externas envíen emails. **NO puedes usar tu contraseña normal de Gmail**.

### Paso 1: Activar la Verificación en Dos Pasos

1. Ve a: https://myaccount.google.com/security
2. Busca la sección "Verificación en dos pasos"
3. Si no está activada, haz clic en "Comenzar" y sigue las instrucciones
4. **Importante**: Debes completar este paso antes de poder generar contraseñas de aplicación

### Paso 2: Generar una Contraseña de Aplicación

1. Una vez activada la verificación en dos pasos, ve a: https://myaccount.google.com/apppasswords
2. Es posible que tengas que iniciar sesión de nuevo
3. En "Selecciona la app", elige "Correo"
4. En "Selecciona el dispositivo", elige "Otro (nombre personalizado)"
5. Escribe un nombre como "Sistema Boda Web"
6. Haz clic en "Generar"
7. Google te mostrará una contraseña de 16 caracteres (por ejemplo: `abcd efgh ijkl mnop`)
8. **MUY IMPORTANTE**: Copia esta contraseña **SIN ESPACIOS**
   - Correcto: `abcdefghijklmnop`
   - Incorrecto: `abcd efgh ijkl mnop`

### Paso 3: Actualizar el Archivo .env

1. Abre el archivo `.env` en la raíz del proyecto
2. Busca la línea que dice `SMTP_PASSWORD=...`
3. Reemplaza el valor con la nueva contraseña (sin espacios)
4. Ejemplo:
   ```
   SMTP_PASSWORD=abcdefghijklmnop
   ```
5. Guarda el archivo

### Paso 4: Reiniciar la Aplicación

1. Detén la aplicación si está corriendo:
   ```bash
   ./scripts/stop
   ```

2. Inicia la aplicación de nuevo:
   ```bash
   ./scripts/run
   ```

3. Verifica los logs de inicio. Deberías ver:
   ```
   ✅ Servidor de correo configurado correctamente
   ```

4. Si ves un error como:
   ```
   ❌ Error en la configuración del servidor de correo
   ```
   Significa que la contraseña sigue siendo incorrecta.

### Paso 5: Probar el Envío de Email

1. Ve a la página de administración: http://localhost:5173/admin
2. En la sección "Probar Configuración de Email" (nueva sección en la parte superior)
3. Introduce tu email de prueba (por ejemplo: `aceciliob@gmail.com`)
4. Haz clic en "Enviar Email de Prueba"
5. Si todo está bien, recibirás un email de prueba en unos segundos
6. Si hay un error, verás un mensaje detallado con instrucciones específicas

## 📧 Emails que se Envían

El sistema envía dos tipos de emails:

### 1. Email de Confirmación al Invitado
- **Se envía a**: El email que el invitado introduce en el formulario
- **Cuándo**: Inmediatamente después de que alguien confirme su asistencia
- **Contenido**: Confirmación de asistencia con detalles del evento
- **Ejemplo**: Si alguien llena el formulario con `aceciliob@gmail.com`, ese email recibirá la confirmación

### 2. Email de Reporte Administrativo
- **Se envía a**: `bodaadrianycelia@gmail.com` (configurado en `CONTACT_EMAIL`)
- **Cuándo**: Inmediatamente después de cada nueva respuesta
- **Contenido**: Resumen de todas las respuestas + archivo Excel adjunto
- **Excel incluye**: Todos los datos de las personas que han respondido

## 🔧 Troubleshooting

### Error: "Invalid login: 535-5.7.8 Username and Password not accepted"

**Causa**: La contraseña de aplicación es incorrecta o ha sido revocada.

**Solución**:
1. Revoca la contraseña de aplicación antigua en: https://myaccount.google.com/apppasswords
2. Genera una nueva contraseña de aplicación (Paso 2 arriba)
3. Actualiza el archivo `.env` (Paso 3 arriba)
4. Reinicia la aplicación (Paso 4 arriba)

### Error: "ECONNREFUSED" o "ETIMEDOUT"

**Causa**: Problema de red o firewall bloqueando la conexión al servidor SMTP.

**Solución**:
1. Verifica tu conexión a internet
2. Verifica que el puerto 587 no esté bloqueado por un firewall
3. Si estás usando una VPN, intenta desconectarla temporalmente

### Los Emails se Envían pero no Llegan

**Causa**: Los emails pueden estar en la carpeta de spam.

**Solución**:
1. Revisa la carpeta de spam/correo no deseado
2. Marca los emails de `bodaadrianycelia@gmail.com` como "No es spam"
3. Añade `bodaadrianycelia@gmail.com` a tus contactos

### Verificar la Configuración Actual

Puedes verificar la configuración actual en el archivo `.env`:

```bash
cat .env | grep SMTP
```

Deberías ver algo como:
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=bodaadrianycelia@gmail.com
SMTP_PASSWORD=abcdefghijklmnop
```

## 📝 Variables de Entorno de Email

Estas son todas las variables relacionadas con email en el archivo `.env`:

- `SMTP_HOST`: Servidor SMTP (debe ser `smtp.gmail.com` para Gmail)
- `SMTP_PORT`: Puerto SMTP (debe ser `587` para Gmail)
- `SMTP_USER`: Tu email de Gmail (`bodaadrianycelia@gmail.com`)
- `SMTP_PASSWORD`: Contraseña de aplicación de Gmail (16 caracteres sin espacios)
- `CONTACT_EMAIL`: Email donde se envían los reportes administrativos (`bodaadrianycelia@gmail.com`)
- `ADMIN_EMAIL_1`: Email del administrador 1 (`aceciliob@gmail.com`)
- `ADMIN_EMAIL_2`: Email del administrador 2 (`celvicare@gmail.com`)

## 🔒 Seguridad

- **NUNCA** compartas tu contraseña de aplicación públicamente
- **NUNCA** subas el archivo `.env` a GitHub o repositorios públicos
- Si crees que tu contraseña ha sido comprometida:
  1. Revoca la contraseña inmediatamente en: https://myaccount.google.com/apppasswords
  2. Genera una nueva contraseña
  3. Actualiza el archivo `.env`

## 📞 Soporte Adicional

Si después de seguir estos pasos los emails siguen sin funcionar:

1. Usa la función "Probar Configuración de Email" en `/admin`
2. Revisa los logs del servidor para ver mensajes de error detallados
3. Verifica que la cuenta `bodaadrianycelia@gmail.com` tenga la verificación en dos pasos activada
4. Asegúrate de que no haya espacios extra en la contraseña en el archivo `.env`
