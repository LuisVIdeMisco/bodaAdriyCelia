# Cómo Reiniciar los Servicios Docker para Subir Fotos

## Respuesta Rápida

Para reiniciar los servicios Docker y poder subir fotos, ejecuta estos comandos en la terminal desde la raíz del proyecto:

```bash
./scripts/stop
./scripts/run
```

¡Eso es todo! Después de esto, podrás subir fotos sin problemas.

---

## Instrucciones Paso a Paso

### 1. Detener los Servicios

Abre una terminal en la raíz del proyecto y ejecuta:

```bash
./scripts/stop
```

Este comando detendrá todos los contenedores Docker (app, nginx, minio, postgres, redis, adminer).

**Espera unos segundos** para asegurarte de que todo se detuvo completamente.

### 2. Iniciar los Servicios

Ahora ejecuta:

```bash
./scripts/run
```

Este comando:
- Configurará el entorno
- Iniciará todos los servicios Docker
- Aplicará la nueva configuración de Nginx
- Ejecutará las migraciones de base de datos si es necesario

**Espera a que veas el mensaje** indicando que el servidor está corriendo (generalmente algo como "Server running on port 3000").

### 3. Verificar que Todo Funciona

1. Abre tu navegador en `http://localhost:8000/admin`
2. Intenta subir una foto
3. Si la subida es exitosa, ¡listo! 🎉

---

## ¿Por Qué es Necesario Reiniciar?

El problema de subida de fotos se resolvió modificando la configuración de Nginx en el archivo `docker/nginx/conf.d/default.conf`. Específicamente, se cambió cómo Nginx envía el header `Host` a MinIO:

**Antes (causaba errores):**
```nginx
proxy_set_header Host $http_host;
```

**Ahora (funciona correctamente):**
```nginx
proxy_set_header Host minio:9000;
```

Este cambio permite que MinIO valide correctamente las firmas S3 de las URLs presignadas. Sin embargo, **los cambios en la configuración de Nginx no se aplican hasta que se reinicia el contenedor**.

Por eso es necesario ejecutar `./scripts/stop` y luego `./scripts/run`.

---

## Comandos Útiles Adicionales

### Ver el Estado de los Contenedores

```bash
docker ps
```

Deberías ver estos contenedores corriendo:
- `nginx` (puerto 8000)
- `minio` (puertos 9000 y 9001)
- `app` (puerto 3000)
- `postgres`
- `redis`
- `adminer`

### Ver los Logs de un Contenedor

Si algo no funciona, puedes ver los logs de cada servicio:

```bash
# Ver logs de Nginx
docker logs <nombre-contenedor-nginx>

# Ver logs de MinIO
docker logs <nombre-contenedor-minio>

# Ver logs de la aplicación
docker logs <nombre-contenedor-app>
```

Para ver el nombre exacto de los contenedores, usa `docker ps`.

### Reinicio Completo (Solución Nuclear)

Si después de reiniciar sigues teniendo problemas, puedes hacer un reinicio completo que elimina todos los datos y vuelve a empezar desde cero:

```bash
./scripts/stop
docker compose -f docker/compose.yaml down -v
sleep 5
./scripts/run
```

**⚠️ ADVERTENCIA:** Esto eliminará TODOS los datos de la base de datos y de MinIO. Solo úsalo en desarrollo.

---

## Solución de Problemas

### "El comando ./scripts/stop no funciona"

**Problema:** Puede que el archivo no tenga permisos de ejecución.

**Solución:**
```bash
chmod +x ./scripts/stop
chmod +x ./scripts/run
./scripts/stop
./scripts/run
```

### "Los contenedores no se detienen"

**Solución:** Fuerza la detención:
```bash
docker compose -f docker/compose.yaml down
./scripts/run
```

### "Sigo sin poder subir fotos después de reiniciar"

**Verifica la configuración de Nginx:**
```bash
docker exec <nombre-contenedor-nginx> cat /etc/nginx/conf.d/default.conf | grep -A 5 "location /wedding-images/"
```

Debes ver:
```nginx
proxy_set_header Host minio:9000;
```

Si ves `proxy_set_header Host $http_host;`, la configuración no se aplicó correctamente. Verifica que el archivo `docker/nginx/conf.d/default.conf` tenga el cambio correcto y vuelve a reiniciar.

---

## Resumen

1. **Detener:** `./scripts/stop`
2. **Esperar:** Unos segundos
3. **Iniciar:** `./scripts/run`
4. **Probar:** Subir una foto en `http://localhost:8000/admin`

Si sigues teniendo problemas, consulta los documentos:
- `VERIFICACION_SUBIDA_IMAGENES.md` - Guía detallada de verificación y solución de problemas
- `DIAGNOSTICO_SUBIDA_IMAGENES.md` - Explicación técnica del problema y la solución

---

## Nota para Producción

Estos comandos son para desarrollo local. Si estás desplegando en un servidor de producción, el proceso puede ser diferente dependiendo de tu plataforma de hosting (AWS, DigitalOcean, Heroku, etc.).
